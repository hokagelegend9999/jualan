from kyt import *
from telethon import events, Button
from kyt.modules import harga, config, database, atlantic
import subprocess
import requests
import random
import io
import urllib.parse
import os

# =================================================================
# GLOBAL VARIABLES (STATE MACHINE)
# =================================================================
user_states = {}   # Untuk User Topup
admin_states = {}  # Untuk Admin Manage User
admin_context = {} # Penyimpanan data sementara Admin

# FUNGSI CEK PROFILE ATLANTIC
def cek_atlantic():
    url = "https://atlantich2h.com/get_profile"
    try:
        payload = {'api_key': config.ATLANTIC_KEY.strip(), 'status': 'aktif'}
        r = requests.post(url, data=payload, headers={'User-Agent': 'Mozilla/5.0'}, timeout=10)
        res = r.json()
        
        status_api = str(res.get('status', 'false')).lower()
        if status_api == 'true':
            data = res['data']
            return data['name'], f"Rp {int(data['balance']):,}".replace(",", ".")
        else:
            return f"Err: {res.get('message', 'Gagal')}", "Rp 0"
    except:
        return "Connection Error", "Rp 0"

# 1. MENU UTAMA HANDLER
@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
@bot.on(events.CallbackQuery(data=b'menu_as_user'))
async def menu_handler(event):
    try:
        sender = await event.get_sender()
        user_id = sender.id
        first_name = sender.first_name
        
        # Reset State saat buka menu
        if user_id in user_states: del user_states[user_id]
        if user_id in admin_states: del admin_states[user_id]
    except:
        user_id = "Unknown"; first_name = "User"

    if isinstance(event, events.CallbackQuery.Event):
        await event.answer("Memuat Data...", alert=False)

    try:
        is_real_admin = False
        try:
            if valid(str(user_id)) == "true": is_real_admin = True
        except: pass

        view_as_user = False
        if hasattr(event, 'data') and event.data == b'menu_as_user':
            view_as_user = True

        if is_real_admin and not view_as_user:
            try:
                ipsaya = subprocess.check_output("curl -s ipv4.icanhazip.com", shell=True).decode("ascii").strip()
            except: ipsaya = "127.0.0.1"

            atl_nama, atl_saldo = cek_atlantic()

            msg = f"""
<b>👑 ADMIN CONTROL PANEL</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>👤 Admin :</b> {first_name}
<b>📡 IP    :</b> {ipsaya}

<b>💰 ATLANTIC H2H PROFILE</b>
<b>👤 Nama  :</b> <code>{atl_nama}</code>
<b>💵 Saldo :</b> <code>{atl_saldo}</code>

<b>📊 MENU MANAJEMEN:</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
"""
            buttons = [
                [Button.inline("☁️ SSH OVPN", data="ssh"), Button.inline("⚡ VMESS", data="vmess")],
                [Button.inline("🚀 VLESS", data="vless"), Button.inline("🛡 TROJAN", data="trojan")],
                [Button.inline("👻 SHADOWSOCKS", data="shadowsocks"), Button.inline("⚙️ SETTINGS", data="setting")],
                [Button.inline("🖥 SYSTEM INFO", data="info"), Button.inline("📝 REGIS IP", data="regis")],
                [Button.inline("👥 MANAGE USER / SALDO", data="manage_users")],
                [Button.inline("👁️ MODE USER (STORE)", data="menu_as_user")],
                [Button.inline("🔙 KEMBALI", data="start")]
            ]
        else:
            database.cek_user(user_id, sender.username if hasattr(sender, 'username') else 'User')
            saldo_asli = database.get_saldo(user_id)
            rp_saldo = f"Rp {saldo_asli:,}".replace(",", ".")

            msg = f"""
<b>🛒 HOKAGE LEGEND STORE</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Halo <b>{first_name}</b>! 👋
Silakan pilih kategori layanan di bawah ini.

🆔 <b>ID Anda :</b> <code>{user_id}</code>
💰 <b>Saldo :</b> <code>{rp_saldo}</code>

<b>👇 PILIH KATEGORI PRODUK:</b>
"""
            buttons = [
                [Button.inline("☁️ SSH OVPN", data="cat_SSH"), Button.inline("⚡ VMESS", data="cat_VMESS")],
                [Button.inline("🚀 VLESS", data="cat_VLESS"), Button.inline("🛡 TROJAN", data="cat_TROJAN")],
                [Button.inline("👻 SHADOWSOCKS", data="cat_SHADOWSOCKS"), Button.inline("💰 TOP UP SALDO", data="topup")],
                [Button.inline("📜 RIWAYAT TRANSAKSI", data="riwayat")],
                [Button.url("💬 HUBUNGI ADMIN", "https://t.me/HookageLegend"), Button.inline("🔙 REFRESH", data="menu_as_user")]
            ]
            if is_real_admin: buttons.append([Button.inline("👑 KEMBALI KE ADMIN PANEL", data="menu")])
            buttons.append([Button.inline("🔙 MENU UTAMA", data="start")])

        if isinstance(event, events.CallbackQuery.Event):
            await event.edit(msg, buttons=buttons, parse_mode='html')
        else:
            await event.reply(msg, buttons=buttons, parse_mode='html')

    except Exception as e:
        try: await event.respond(f"❌ <b>ERROR:</b> {str(e)}", parse_mode='html')
        except: pass

# =================================================================
# HANDLER MANAGE USER & SALDO (ADMIN)
# =================================================================
@bot.on(events.CallbackQuery(data=b'manage_users'))
async def manage_users_handler(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        return await event.answer("Akses Ditolak!", alert=True)
    
    users = database.get_all_users(limit=15)
    
    msg = "<b>👥 MANAJEMEN USER & SALDO</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
    msg += "<i>Menampilkan Top 15 User (Urut Saldo):</i>\n\n"
    
    if not users:
        msg += "⚠️ Belum ada user terdaftar."
    else:
        for u in users:
            uid, uname, saldo = u
            uname = uname if uname else "Unknown"
            msg += f"🆔 <code>{uid}</code> | 💰 Rp {saldo:,}\n👤 {uname}\n───────────────────\n"
            
    msg += "\n<b>👇 PILIH AKSI:</b>"
    
    buttons = [
        [Button.inline("➕ TAMBAH SALDO", data="adm_add_saldo"), Button.inline("➖ KURANG SALDO", data="adm_min_saldo")],
        [Button.inline("🔙 KEMBALI", data="menu")]
    ]
    await event.edit(msg, buttons=buttons, parse_mode='html')

# 1. TRIGGER TOMBOL TAMBAH/KURANG (SET STATE)
@bot.on(events.CallbackQuery(pattern=b'adm_(add|min)_saldo'))
async def admin_saldo_start(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true": return
    
    action = event.data.decode('utf-8')
    tipe_aksi = "TAMBAH" if "add" in action else "KURANG"
    
    # SET STATE: Menunggu ID User
    admin_states[sender.id] = 'WAIT_TARGET_ID'
    admin_context[sender.id] = {'type': tipe_aksi}
    
    btn_batal = [[Button.inline("❌ BATAL / KEMBALI", data="cancel_admin_process")]]
    
    await event.edit(f"<b>📝 {tipe_aksi} SALDO USER</b>\n\nSilakan kirim <b>ID Telegram User</b>.\n(Lihat ID di list sebelumnya)\n\nAtau Klik tombol Batal dibawah.", buttons=btn_batal, parse_mode='html')

# 2. TRIGGER TOMBOL BATAL
@bot.on(events.CallbackQuery(data=b'cancel_admin_process'))
async def cancel_admin_handler(event):
    user_id = event.sender_id
    # Hapus State
    if user_id in admin_states: del admin_states[user_id]
    if user_id in admin_context: del admin_context[user_id]
    
    await event.edit("❌ <b>Proses Dibatalkan.</b>", buttons=[[Button.inline("🔙 Menu Admin", data="manage_users")]], parse_mode='html')

# 3. HANDLER INPUT TEXT ADMIN (STATE MACHINE)
@bot.on(events.NewMessage(incoming=True))
async def admin_input_handler(event):
    user_id = event.sender_id
    
    # Cek apakah user ini Admin yg sedang input data?
    if user_id not in admin_states:
        return # Bukan urusan handler ini
        
    state = admin_states[user_id]
    text = event.raw_text.strip()
    
    # Command Batal
    if text == '/cancel':
        if user_id in admin_states: del admin_states[user_id]
        if user_id in admin_context: del admin_context[user_id]
        return await event.reply("❌ Proses Dibatalkan.", buttons=[[Button.inline("🔙 Menu Admin", data="manage_users")]])

    btn_batal = [[Button.inline("❌ BATAL / KEMBALI", data="cancel_admin_process")]]

    # --- TAHAP 1: TERIMA ID USER ---
    if state == 'WAIT_TARGET_ID':
        if not text.isdigit():
            return await event.reply("❌ <b>ID harus angka!</b> Silakan kirim ID yang benar.", buttons=btn_batal, parse_mode='html')
        
        target_id = text
        admin_context[user_id]['target_id'] = target_id
        
        # Cek Saldo User
        saldo_curr = database.get_saldo(target_id)
        
        # Lanjut ke Tahap 2: Minta Nominal
        admin_states[user_id] = 'WAIT_NOMINAL'
        
        tipe = admin_context[user_id]['type']
        await event.reply(f"✅ ID Diterima: <code>{target_id}</code>\n💰 Saldo Sekarang: Rp {saldo_curr:,}\n\n<b>Masukan Nominal {tipe}:</b>\nContoh: 50000", buttons=btn_batal, parse_mode='html')

    # --- TAHAP 2: TERIMA NOMINAL ---
    elif state == 'WAIT_NOMINAL':
        if not text.isdigit():
            return await event.reply("❌ <b>Nominal harus angka!</b> Contoh: 50000", buttons=btn_batal, parse_mode='html')
            
        nominal = int(text)
        data_ctx = admin_context[user_id]
        target_id = data_ctx['target_id']
        tipe = data_ctx['type']
        
        msg_wait = await event.reply("🔄 Memproses...", parse_mode='html')
        
        try:
            if tipe == "TAMBAH":
                database.tambah_saldo(target_id, nominal, "Topup Manual Admin")
                msg_done = f"✅ <b>BERHASIL NAMBAH SALDO</b>\n\n🆔 User: <code>{target_id}</code>\n💰 Jumlah: Rp {nominal:,}\n\nSaldo user telah bertambah."
            else:
                curr = database.get_saldo(target_id)
                if curr < nominal:
                    return await msg_wait.edit(f"❌ <b>GAGAL:</b> Saldo user cuma Rp {curr:,}. Tidak bisa dikurangi Rp {nominal:,}.", buttons=btn_batal, parse_mode='html')
                
                database.kurang_saldo(target_id, nominal, "Penyesuaian Admin")
                msg_done = f"✅ <b>BERHASIL POTONG SALDO</b>\n\n🆔 User: <code>{target_id}</code>\n💰 Jumlah: Rp {nominal:,}\n\nSaldo user telah dikurangi."
            
            # Reset State (Selesai)
            del admin_states[user_id]
            del admin_context[user_id]
            
            await msg_wait.edit(msg_done, buttons=[[Button.inline("🔙 Kembali ke List", data="manage_users")]], parse_mode='html')
            
            # Notif ke User
            try:
                ket = "Penambahan" if tipe == "TAMBAH" else "Pengurangan"
                await bot.send_message(int(target_id), f"🔔 <b>INFO SALDO</b>\n\nAdmin telah melakukan {ket} saldo sebesar <b>Rp {nominal:,}</b> pada akun Anda.")
            except: pass
            
        except Exception as e:
            await msg_wait.edit(f"❌ Error: {e}", buttons=btn_batal)

# =================================================================
# HANDLER LAINNYA
# =================================================================
@bot.on(events.CallbackQuery(pattern=b'cat_'))
async def category_handler(event):
    try:
        kategori_pilih = event.data.decode('utf-8').split('_')[1]
        msg = f"<b>📦 KATEGORI: {kategori_pilih}</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n<i>Silakan pilih paket:</i>\n"
        buttons = []
        found = False
        for kode, info in harga.daftar_produk.items():
            if info['service'] == kategori_pilih:
                found = True
                nama = info['nama']; harga_rp = harga.format_rupiah(info['harga'])
                buttons.append([Button.inline(f"{nama} - {harga_rp}", data=f"buy_{kode}")])
        if not found: msg += "\n❌ <i>Produk belum tersedia.</i>"
        buttons.append([Button.inline("🔙 KEMBALI", data="menu_as_user")])
        await event.edit(msg, buttons=buttons, parse_mode='html')
    except: pass

@bot.on(events.CallbackQuery(pattern=b'buy_'))
async def buy_confirm_handler(event):
    try:
        kode_produk = event.data.decode('utf-8').split('_', 1)[1]
        if kode_produk in harga.daftar_produk:
            info = harga.daftar_produk[kode_produk]
            msg = f"<b>🛒 KONFIRMASI</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n<b>📦 Paket :</b> {info['nama']}\n<b>💰 Harga :</b> {harga.format_rupiah(info['harga'])}\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"
            buttons = [[Button.inline("✅ BELI", data=f"fix_buy_{kode_produk}")], [Button.inline("❌ BATAL", data=f"cat_{info['service']}")]]
            await event.edit(msg, buttons=buttons, parse_mode='html')
    except: pass

@bot.on(events.CallbackQuery(data=b'riwayat'))
async def history_handler(event):
    user_id = event.sender_id
    data_trx = database.get_riwayat(user_id, limit=10)
    if not data_trx: msg = "❌ <b>Belum ada riwayat.</b>"
    else:
        msg = "<b>📜 10 RIWAYAT TRANSAKSI</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        for row in data_trx:
            trx, tipe, jml, sts, tgl, ket = row
            icon = "🟢" if sts == 'SUCCESS' else ("🟡" if sts == 'PENDING' else "🔴")
            msg += f"<b>{icon} {tipe}</b> | Rp {jml:,}\n📅 {str(tgl).split('.')[0]}\n📝 {ket}\n───────────────────\n"
    await event.edit(msg, buttons=[[Button.inline("🔙 KEMBALI", data="menu_as_user")]], parse_mode='html')

@bot.on(events.CallbackQuery(data=b'topup'))
async def topup_menu_handler(event):
    if event.sender_id in user_states: del user_states[event.sender_id]
    
    msg = """
<b>💰 PILIH METODE TOPUP</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Silakan pilih metode deposit yang Anda inginkan:

<b>1️⃣ OTOMATIS</b> (Rekomendasi)
• Saldo masuk otomatis dalam hitungan detik.
• Support QRIS Instant (Semua E-Wallet/Bank).
• Minimal Rp 10.000.

<b>2️⃣ MANUAL</b> (Alternatif)
• Transfer manual ke QRIS Admin.
• Wajib kirim bukti transfer ke Admin.
• Saldo diproses manual (Human Process).
"""
    buttons = [
        [Button.inline("⚡ QRIS INSTANT (Otomatis)", data="topup_auto")],
        [Button.inline("🏦 QRIS MANUAL (Chat Admin)", data="topup_manual")],
        [Button.inline("🔙 KEMBALI", data="menu_as_user")]
    ]
    await event.edit(msg, buttons=buttons, parse_mode='html')

@bot.on(events.CallbackQuery(data=b'topup_manual'))
async def topup_manual_handler(event):
    file_path = '/usr/bin/kyt/modules/qris/qris.jpg'
    if not os.path.exists(file_path):
        return await event.answer("❌ File QRIS Manual belum diupload di VPS!", alert=True)

    capt = """
<b>🏦 TOP UP MANUAL (ADMIN)</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Silakan Scan QRIS di atas untuk melakukan transfer.

⚠️ <b>PENTING:</b>
1. Transfer sesuai nominal yang Anda butuhkan.
2. Screenshot bukti pembayaran/transfer.
3. Kirim bukti screenshot ke kontak Admin di bawah ini.

<b>👇 KONTAK KONFIRMASI:</b>
"""
    wa_link = "https://wa.me/6287726917005?text=Halo%20Admin,%20saya%20mau%20konfirmasi%20Topup%20Saldo%20Manual."
    tg_link = "https://t.me/HookageLegend"

    buttons = [
        [Button.url("🟢 WHATSAPP ADMIN", wa_link)],
        [Button.url("🔵 TELEGRAM ADMIN", tg_link)],
        [Button.inline("🔙 KEMBALI", data="topup")]
    ]
    
    await event.delete()
    await event.client.send_file(event.chat_id, file_path, caption=capt, buttons=buttons, parse_mode='html')

@bot.on(events.CallbackQuery(data=b'topup_auto'))
async def topup_auto_handler(event):
    user_states[event.sender_id] = 'WAITING_NOMINAL'
    msg = """
<b>⚡ TOP UP OTOMATIS (QRIS INSTANT)</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Silakan ketik nominal deposit.
🔹 <b>Minimal:</b> Rp 10.000
🔹 <b>Metode:</b> QRIS Instant (Otomatis)
<i>Contoh ketik: 15000</i>
"""
    buttons = [[Button.inline("🔙 BATAL / KEMBALI", data="topup")]]
    await event.edit(msg, buttons=buttons, parse_mode='html')

@bot.on(events.CallbackQuery(data=b'cancel_topup'))
async def cancel_topup_handler(event):
    if event.sender_id in user_states: del user_states[event.sender_id]
    await event.edit("❌ Topup Dibatalkan.", buttons=[[Button.inline("🔙 KEMBALI", data="menu_as_user")]], parse_mode='html')

@bot.on(events.NewMessage(incoming=True))
async def input_nominal_handler(event):
    user_id = event.sender_id
    
    # Cek State: Jika sedang di state Admin, jangan jalankan handler user ini
    if user_id in admin_states:
        return 

    if user_states.get(user_id) == 'WAITING_NOMINAL':
        text = event.raw_text.strip()
        if not text.isdigit(): return await event.reply("⚠️ Harap masukkan angka saja.")
        
        nominal = int(text)
        if nominal < 10000: return await event.reply("⚠️ Minimal deposit Rp 10.000.")
        
        del user_states[user_id]
        msg_wait = await event.reply("🔄 <b>Sedang membuat tagihan QRIS...</b>", parse_mode='html')
        
        try:
            metode_list = atlantic.get_metode_pembayaran()
            target, tipe = None, None
            min_limit_found = 0
            
            for m in metode_list:
                nama = m['name'].lower()
                if 'qris' in nama and ('instant' in nama or 'otomatis' in nama):
                    min_val = int(m['min'])
                    if min_limit_found == 0 or min_val < min_limit_found:
                        min_limit_found = min_val
                    if min_val <= nominal <= int(m['max']):
                        target, tipe = m['metode'], m['type']
                        break
            
            if not target: 
                err_text = f"❌ <b>Nominal Tidak Didukung!</b>\n\nNominal: Rp {nominal:,}\n"
                if min_limit_found > 0:
                    err_text += f"⚠️ <b>Minimal Deposit Atlantic:</b> Rp {min_limit_found:,}\n"
                else:
                    err_text += "⚠️ Metode QRIS Instant sedang tidak tersedia.\n"
                err_text += "\nSilakan coba nominal yang lebih besar."
                return await msg_wait.edit(err_text)

            reff_id = str(random.randint(1000000000, 9999999999))
            res = atlantic.create_deposit(reff_id, nominal, tipe, target)
            
            if str(res.get('status', 'false')).lower() == 'true':
                data = res['data']
                at_id = data.get('id', '0')
                database.new_deposit(user_id, reff_id, nominal, at_id, target)
                
                bayar = data.get('nominal') + data.get('tambahan', 0) + data.get('fee', 0)
                capt = f"""
<b>✅ TAGIHAN QRIS INSTANT</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>🆔 Reff ID:</b> <code>{reff_id}</code>
<b>💰 Total Bayar:</b> <code>Rp {bayar:,}</code>
<b>⏳ Expired:</b> {data.get('expired_at', '-')}

⚠️ <i>Bayar sesuai nominal yang tertera. Saldo masuk otomatis.</i>
<i>Klik tombol <b>CEK STATUS</b> jika sudah transfer.</i>
"""
                buttons_qris = [
                    [Button.inline("🔄 CEK STATUS PEMBAYARAN", data=f"cek_status_{at_id}_{reff_id}")],
                    [Button.inline("🔙 BATAL / KEMBALI", data="menu_as_user")]
                ]

                qr_content = data.get('qr_string')
                qr_url_atlantic = data.get('qr_image')

                if qr_content:
                    try:
                        encoded_qr = urllib.parse.quote(qr_content)
                        gen_url = f"https://api.qrserver.com/v1/create-qr-code/?size=500x500&margin=35&data={encoded_qr}"
                        r_img = requests.get(gen_url, timeout=10)
                        if r_img.status_code == 200:
                            file_bytes = io.BytesIO(r_img.content)
                            file_bytes.name = "qrcode.png"
                            await event.client.send_file(event.chat_id, file_bytes, caption=capt, buttons=buttons_qris, parse_mode='html')
                            await msg_wait.delete()
                        else:
                            raise Exception("Gagal Generate")
                    except Exception as e:
                         await msg_wait.edit(f"{capt}\n\n❌ Gagal generate gambar.\n<b>Klik Link QR:</b> {qr_url_atlantic}", buttons=buttons_qris, parse_mode='html')
                elif qr_url_atlantic:
                    await msg_wait.edit(f"{capt}\n\n⚠️ Gagal generate QR Lokal.\n<b>Klik untuk Bayar:</b> {qr_url_atlantic}", buttons=buttons_qris, parse_mode='html')
                else:
                    await msg_wait.edit(f"❌ <b>Error:</b> Data QR Code tidak ditemukan.", buttons=buttons_qris)
            else:
                await msg_wait.edit(f"❌ <b>Gagal:</b> {res.get('message', 'Unknown Error')}", buttons=[[Button.inline("🔙 KEMBALI", data="menu_as_user")]], parse_mode='html')
        except Exception as e:
            await msg_wait.edit(f"❌ <b>System Error:</b> {str(e)}")

@bot.on(events.CallbackQuery(pattern=b'cek_status_'))
async def check_status_trx_handler(event):
    try:
        parts = event.data.decode('utf-8').split('_')
        at_id = parts[2]
        reff_id = parts[3]
        user_id = event.sender_id
        
        local_status, local_amount = database.get_trx_status(reff_id)
        if local_status == 'SUCCESS':
            return await event.answer("✅ Pembayaran ini SUDAH SUKSES!", alert=True)
            
        await event.answer("🔄 Mengecek ke server...", alert=False)
        
        res = atlantic.check_status(at_id)
        
        if str(res.get('status', 'false')).lower() == 'true':
            data = res['data']
            status_atl = data.get('status') 
            
            if status_atl == 'success':
                nominal_masuk = int(data.get('get_balance', 0))
                database.update_trx_success(reff_id)
                database.tambah_saldo(user_id, nominal_masuk, "Deposit Otomatis")
                await event.edit(f"""
<b>✅ PEMBAYARAN BERHASIL!</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>🆔 Reff ID:</b> <code>{reff_id}</code>
<b>💰 Saldo Masuk:</b> <code>Rp {nominal_masuk:,}</code>

<i>Terima kasih! Saldo telah ditambahkan.</i>
""", buttons=[[Button.inline("🔙 KEMBALI KE MENU", data="menu_as_user")]], parse_mode='html')

            elif status_atl == 'processing':
                await event.answer("⚠️ Mendeteksi Deposit Processing... Mencoba Instant Claim...", alert=False)
                res_inst = atlantic.req_instant_deposit(at_id, 'true')
                
                if str(res_inst.get('status', 'false')).lower() == 'true':
                    data_inst = res_inst['data']
                    nominal_masuk = int(data_inst.get('total_diterima', 0))
                    database.update_trx_success(reff_id)
                    database.tambah_saldo(user_id, nominal_masuk, "Deposit Instant (Force)")
                    await event.edit(f"""
<b>✅ PEMBAYARAN BERHASIL (INSTANT)</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>🆔 Reff ID:</b> <code>{reff_id}</code>
<b>💰 Saldo Masuk:</b> <code>Rp {nominal_masuk:,}</code>

<i>Deposit berhasil dicairkan secara instan.</i>
""", buttons=[[Button.inline("🔙 KEMBALI KE MENU", data="menu_as_user")]], parse_mode='html')
                else:
                    err_msg = res_inst.get('message', 'Gagal Instant')
                    await event.answer(f"⏳ Pembayaran Masuk (Processing).\n{err_msg}\nSaldo akan masuk otomatis besok.", alert=True)

            elif status_atl == 'pending':
                await event.answer(f"⏳ STATUS: PENDING\nPembayaran belum diterima sistem.", alert=True)
                
            elif status_atl in ['expired', 'failed']:
                await event.edit(f"❌ <b>TRANSAKSI GAGAL</b>\nStatus: {status_atl}", buttons=[[Button.inline("🔙 KEMBALI", data="menu_as_user")]], parse_mode='html')
            else:
                await event.answer(f"Status: {status_atl}", alert=True)
        else:
            pesan_err = res.get('message', 'Unknown Error')
            await event.answer(f"❌ Gagal Cek: {pesan_err}", alert=True)
            
    except Exception as e:
        await event.answer(f"Error System: {str(e)}", alert=True)