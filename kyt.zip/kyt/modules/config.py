# FILE: /usr/bin/kyt/modules/config.py

# =================================================================
# 🔐 CONFIGURATION FILE
# Simpan semua data sensitif di sini. Jangan disebar!
# =================================================================

# 1. TELEGRAM ADMIN CONFIG
# ID Telegram Owner (Angka) - Ganti dengan ID Anda
OWNER_ID = "7764252283"

# 2. ATLANTIC H2H API KEY
# Ambil dari https://atlantich2h.com/dashboard
ATLANTIC_KEY = "Zv9V6vj9CxUKpgcCiQnk0taynXhzkqowuOB1ctATQRy6hKc8n7tKzbnl6b1d0Gpg2cwjDpsIpSGsShXJ1tYn7Uc2S6zZHNLjngGD"

# 3. GLOBAL DOMAIN (Opsional, jika ingin setting manual)
# Jika dikosongkan, script akan mencoba deteksi otomatis atau pakai default
DOMAIN_MANUAL = "singa.haniefautophile.biz.id"
