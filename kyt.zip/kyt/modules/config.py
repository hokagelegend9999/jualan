# FILE: /usr/bin/kyt/modules/config.py

# =================================================================
# 🔐 CONFIGURATION FILE
# Simpan semua data sensitif di sini. Jangan disebar!
# =================================================================

# 1. TELEGRAM ADMIN CONFIG
# ID Telegram Owner (Angka) - Ganti dengan ID Anda
OWNER_ID = "1469244768"

# 2. ATLANTIC H2H API KEY
# Ambil dari https://atlantich2h.com/dashboard
ATLANTIC_KEY = "isRvfcVi2uUCGjwpN7OoFUvxDshDroXlrv0gDICCVmzeGimCg6VhUmRFwwaB6cKP6OTdf4z36bbYwGM8LpgtzkJR1LqsK2pzBT30"

# 3. GLOBAL DOMAIN (Opsional, jika ingin setting manual)
# Jika dikosongkan, script akan mencoba deteksi otomatis atau pakai default
DOMAIN_MANUAL = "uji.hokage.web.id"