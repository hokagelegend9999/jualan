from kyt import *
from telethon import events, Button
from kyt.modules import database, harga
import subprocess
import asyncio
import math
import re
import requests
import datetime as DT
import os

# =================================================================
# FUNGSI PEMBANTU (HELPER)
# =================================================================

def get_vless_data():
    """Mengambil data user VLESS dari config.json"""
    try:
        cmd = 'grep -E "^#& " "/etc/xray/config.json"'
        raw_output = subprocess.check_output(cmd, shell=True).decode("utf-8")
        data_list = []
        seen_users = set() 
        
        for line in raw_output.splitlines():
            if line.strip():
                parts = line.split()
                if len(parts) >= 3:
                    user = parts[1]
                    exp = parts[2]
                    if user not in seen_users:
                        data_list.append({"user": user, "exp": exp})
                        seen_users.add(user)
        return data_list
    except:
        return []

def render_page_content(data_list, page, mode="list", item_per_page=5):
    total_items = len(data_list)
    total_pages = math.ceil(total_items / item_per_page)
    
    if page < 0: page = 0
    if total_pages > 0 and page >= total_pages: page = total_pages - 1
    if total_pages == 0: page = 0 
    
    start = page * item_per_page
    end = start + item_per_page
    sliced_data = data_list[start:end]
    
    title = "⚡ LIST USER VLESS" if mode == "list" else "🗑️ DELETE USER VLESS"
    msg = f"<b>{title}</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
    
    flat_buttons = [] 
    
    if not sliced_data:
        msg += "<i>⚠️ Tidak ada user VLESS.</i>"
    else:
        for row in sliced_data:
            user = row["user"]
            exp = row["exp"]
            try:
                today = DT.date.today()
                exp_dt = DT.datetime.strptime(exp, "%Y-%m-%d").date()
                diff = (exp_dt - today).days
                if diff >= 0: status = f"🟢 Active ({diff} Hari)"
                else: status = f"🔴 Expired ({abs(diff)} Hari Lalu)"
            except: status = "⚪ Unlimited"

            msg += f"<b>👤 User :</b> <code>{user}</code>\n<b>📅 Exp  :</b> <code>{exp}</code>\n<b>💎 Stat :</b> {status}\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
            
            if mode == "list":
                flat_buttons.append(Button.inline(f"🔍 {user}", data=f"vlDetail_{user}_{page}"))
            else:
                flat_buttons.append(Button.inline(f"🗑️ {user}", data=f"vlDelExec_{user}_{page}"))

    msg += f"\n📊 <b>Total:</b> {total_items} Users | 📄 <b>Page:</b> {page+1}/{total_pages}"
    grid_buttons = [flat_buttons[i:i + 2] for i in range(0, len(flat_buttons), 2)]
    return msg, total_pages, grid_buttons

# =================================================================
# 1. MENU UTAMA VLESS
# =================================================================
@bot.on(events.CallbackQuery(data=b'vless'))
async def vless_menu(event):
    sender = await event.get_sender()
    user_id = str(sender.id)
    
    user_balance = database.get_saldo(user_id)
    try: price_vless = harga.daftar_produk['VLESS1']['harga']
    except: price_vless = 0

    try:
        if valid(user_id) != "true":
            return await event.answer("Access Denied", alert=True)
    except: pass

    try:
        try:
            z = requests.get("http://ip-api.com/json/?fields=country,isp", timeout=2).json()
            isp = z.get("isp", "Unknown")
            country = z.get("country", "Unknown")
        except: isp, country = "Unknown", "Unknown"
        
        try: my_domain = DOMAIN
        except: my_domain = "Premium Server"

        msg = f"""
<b>⚡ VLESS MANAGER</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>💰 Saldo Anda  :</b> <code>Rp {user_balance:,}</code>
<b>🏷️ Harga Dasar :</b> <code>Rp {price_vless:,}</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>🟢 Service Status :</b> <code>Active</code>
<b>🌐 Hostname/IP    :</b> <code>{my_domain}</code>
<b>📡 ISP Provider   :</b> <code>{isp}</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
"""
        inline = [
            [Button.inline("⚡ TRIAL", "trial-vless"), Button.inline("⚡ CREATE (ADMIN)", "create-vless")],
            [Button.inline("📊 LIST USER", "list-vless"), Button.inline("🗑️ DELETE", "delete-vless")],
            [Button.inline("‹ Main Menu ›", "menu")]
        ]
        await event.edit(msg, buttons=inline, parse_mode='html')
    except Exception as e:
        await event.respond(f"Error Menu: {str(e)}")

# =================================================================
# 2. FITUR BELI UNTUK USER (OTOMATIS)
# =================================================================
@bot.on(events.CallbackQuery(pattern=b'fix_buy_VLESS'))
async def buy_vless_user(event):
    user_id = str(event.sender_id)
    
    try:
        kode_produk = event.data.decode('utf-8').replace("fix_buy_", "")
        
        if kode_produk not in harga.daftar_produk:
            return await event.answer("❌ Produk tidak ditemukan/terhapus.", alert=True)
            
        produk = harga.daftar_produk[kode_produk]
        nama_paket = produk['nama']
        biaya = produk['harga']
        durasi = produk['exp']
        limit_ip = produk['limit']
        quota = produk['quota'] 

        saldo_user = database.get_saldo(user_id)
        if saldo_user < biaya:
            return await event.answer(f"❌ Saldo Kurang!\nSaldo: Rp {saldo_user:,}\nHarga: Rp {biaya:,}", alert=True)

        async with bot.conversation(event.chat_id, timeout=45) as conv:
            await event.edit(f"<b>👤 Masukkan Username VLESS:</b>\n<i>(Hanya huruf & angka, tanpa spasi)</i>", parse_mode='html')
            try:
                resp = await conv.wait_event(events.NewMessage(incoming=True, from_users=event.sender_id))
                username = resp.raw_text.strip().replace(" ", "")
                if not username.isalnum():
                    return await event.respond("❌ Username hanya boleh huruf dan angka.")
            except asyncio.TimeoutError:
                return await event.respond("❌ Waktu habis.")

        msg_pro = await event.respond("🔄 <b>Memproses Transaksi...</b>", parse_mode='html')

        cmd = f'printf "%s\n" "{username}" "{durasi}" "{quota}" "{limit_ip}" | addvless-bot'
        
        try:
            process = subprocess.check_output(cmd, shell=True).decode("utf-8")
            
            # Ambil Semua Link (TLS, Non-TLS, GRPC)
            links = [x.group() for x in re.finditer("vless://(.*)", process)]
            if not links:
                raise Exception("Gagal mengambil link dari VPS.")

            # Potong Saldo
            database.kurang_saldo(user_id, biaya, f"Beli {nama_paket}")
            sisa_saldo = database.get_saldo(user_id)

            # --- PARSING DATA UNTUK FORMAT BARU ---
            link_tls  = links[0].strip()
            link_ntls = links[1].strip() if len(links) > 1 else "Not Available"
            link_grpc = links[2].strip() if len(links) > 2 else "Not Available"
            
            try:
                # Ambil UUID dan Domain dari Link TLS
                # Format: vless://UUID@DOMAIN:PORT...
                clean_link = link_tls.replace("vless://", "")
                uuid = clean_link.split("@")[0]
                domain = clean_link.split("@")[1].split(":")[0]
            except:
                uuid = "Unknown"
                domain = "Premium Server"
            
            today = DT.date.today()
            exp_date = today + DT.timedelta(days=int(durasi))
            today_str = today.strftime("%d/%m/%Y")
            
            # Handling Tampilan Quota
            quota_display = f"{quota} GB" if int(quota) > 0 else "Unlimited"

            struk = f"""
<b>✅ PEMBELIAN SUKSES</b>
========================================
 <b>🚀 AKUN VLESS PREMIUM</b>
========================================

 <b>📋 INFORMASI AKUN</b>
 <b>👤 Username :</b> <code>{username}</code>
 <b>🌐 Domain   :</b> <code>{domain}</code>
 <b>🔒 Port TLS :</b> <code>443</code>
 <b>🔓 Port None:</b> <code>80</code>
 <b>🔄 Port GRPC:</b> <code>443</code>
 <b>🔑 UUID     :</b> <code>{uuid}</code>
 <b>📡 Network  :</b> <code>WS / GRPC</code>
 <b>🛤️ Path     :</b> <code>/vless</code> / <code>vless-grpc</code>

 <b>🔗 FORMAT KONEKSI</b>
 <b>🔮 TLS:</b>
<code>{link_tls}</code>

 <b>🔮 NON-TLS:</b>
<code>{link_ntls}</code>

 <b>🔮 GRPC:</b>
<code>{link_grpc}</code>

 <b>ℹ️ INFORMASI TAMBAHAN</b>
 <b>💰 Harga    :</b> Rp {biaya:,}
 <b>💳 Sisa     :</b> Rp {sisa_saldo:,}
 <b>📅 Expired  :</b> {exp_date}
 <b>📱 IP Limit :</b> {limit_ip} IP
 <b>💾 Quota    :</b> {quota_display}

========================================
ᵗᵉʳⁱᵐᵃᵏᵃˢⁱʰ ᵗᵉˡᵃʰ ᵐᵉⁿᵍᵍᵘⁿᵃᵏᵃⁿ ˡᵃʸᵃⁿᵃⁿ ᵏᵃᵐⁱ
Generated on {today_str}
========================================
"""
            await msg_pro.edit(struk, parse_mode='html', buttons=[[Button.inline("🔙 Menu Utama", "menu")]])

        except Exception as e:
            await msg_pro.edit(f"❌ <b>Gagal Membuat Akun:</b>\n{str(e)}\n\n<i>Saldo tidak terpotong.</i>", parse_mode='html')

    except Exception as e:
        await event.respond(f"Error System: {str(e)}")

# =================================================================
# 3. CREATE VLESS MANUAL (KHUSUS ADMIN)
# =================================================================
@bot.on(events.CallbackQuery(data=b'create-vless'))
async def create_vless_admin(event):
    chat = event.chat_id
    sender = await event.get_sender()
    try:
        if valid(str(sender.id)) != "true":
            return await event.answer("❌ Menu ini khusus Admin!", alert=True)
    except: pass

    async def manual_process():
        try:
            async with bot.conversation(chat, timeout=60) as conv:
                await event.respond('<b>👤 Input Username:</b>', parse_mode='html')
                res = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                user = res.raw_text.strip()
                
                await event.respond('<b>📅 Input Expired (Hari):</b>', parse_mode='html')
                res = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                exp = res.raw_text.strip()

                await event.respond('<b>💾 Input Quota (GB):</b>', parse_mode='html')
                res = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                quota = res.raw_text.strip()

                await event.respond('<b>📱 Input IP Limit:</b>', parse_mode='html')
                res = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                limit = res.raw_text.strip()
            
            msg_load = await event.respond("Processing...", parse_mode='html')
            cmd = f'printf "%s\n" "{user}" "{exp}" "{quota}" "{limit}" | addvless-bot'
            
            try:
                process = subprocess.check_output(cmd, shell=True).decode("utf-8")
                links = [x.group() for x in re.finditer("vless://(.*)", process)]
                
                link_tls  = links[0].strip()
                link_ntls = links[1].strip() if len(links) > 1 else "Not Available"
                link_grpc = links[2].strip() if len(links) > 2 else "Not Available"

                try:
                    clean_link = link_tls.replace("vless://", "")
                    uuid = clean_link.split("@")[0]
                    domain = clean_link.split("@")[1].split(":")[0]
                except:
                    uuid = "Unknown"; domain = "Premium Server"

                quota_display = f"{quota} GB" if int(quota) > 0 else "Unlimited"
                today_str = DT.date.today().strftime("%d/%m/%Y")

                struk = f"""
<b>✅ VLESS CREATED (ADMIN)</b>
========================================
 <b>🚀 AKUN VLESS PREMIUM</b>
========================================

 <b>📋 INFORMASI AKUN</b>
 <b>👤 Username :</b> <code>{user}</code>
 <b>🌐 Domain   :</b> <code>{domain}</code>
 <b>🔑 UUID     :</b> <code>{uuid}</code>
 <b>📡 Network  :</b> <code>WS / GRPC</code>

 <b>🔗 FORMAT KONEKSI</b>
 <b>🔮 TLS:</b>
<code>{link_tls}</code>

 <b>🔮 NON-TLS:</b>
<code>{link_ntls}</code>

 <b>🔮 GRPC:</b>
<code>{link_grpc}</code>

 <b>ℹ️ INFORMASI TAMBAHAN</b>
 <b>📅 Expired  :</b> {exp} Hari
 <b>📱 IP Limit :</b> {limit} IP
 <b>💾 Quota    :</b> {quota_display}

========================================
Generated on {today_str}
========================================
"""
                await msg_load.edit(struk, parse_mode='html', buttons=[[Button.inline("Menu", "menu")]])
            except Exception as e:
                await msg_load.edit(f"❌ Error: {e}")
                
        except asyncio.TimeoutError:
            await event.respond("❌ Waktu Habis.")

    await manual_process()

# =================================================================
# 4. TRIAL VLESS
# =================================================================
@bot.on(events.CallbackQuery(data=b'trial-vless'))
async def trial_vless(event):
    chat = event.chat_id
    sender = await event.get_sender()
    try:
        if valid(str(sender.id)) != "true":
            return await event.answer("Akses Ditolak", alert=True)
    except: pass

    async def trial_vless_process(event):
        try:
            async with bot.conversation(chat, timeout=60) as conv:
                await event.respond("<b>⏱️ Input Durasi Trial (Menit):</b>\n<i>Contoh: 30</i>", parse_mode='html')
                try:
                    resp = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                    exp = resp.raw_text.strip()
                    if not exp.isdigit(): return await event.respond("❌ Angka saja.")
                except: return await event.respond("❌ Timeout")

            msg_load = await event.respond("Creating...", parse_mode='html')
            cmd = f'printf "%s\n" "{exp}" | bot-trialvless'
            try:
                a = subprocess.check_output(cmd, shell=True).decode("utf-8")
                links = [x.group() for x in re.finditer("vless://(.*)", a)]
                
                try: remarks = links[0].split("#")[-1]
                except: remarks = "Trial"

                await msg_load.edit(f"""
<b>✅ TRIAL SUKSES</b>
<b>User:</b> {remarks}
<b>Exp:</b> {exp} Menit
<b>Link:</b> <code>{links[0]}</code>
""", parse_mode='html', buttons=[[Button.inline("Menu", "menu")]])
            except: 
                await msg_load.edit("❌ Gagal.")
        except Exception as e:
            await event.respond(f"Error: {e}")

    await trial_vless_process(event)

# =================================================================
# 5. LIST & DELETE HANDLER
# =================================================================
@bot.on(events.CallbackQuery(data=b'list-vless'))
async def list_vless_handler(event):
    sender = await event.get_sender()
    try:
        if valid(str(sender.id)) != "true": return
    except: pass

    data_list = get_vless_data()
    msg, total_pages, user_buttons = render_page_content(data_list, 0, mode="list")
    
    nav_buttons = []
    if total_pages > 1:
        nav_buttons.append(Button.inline("Next ⏩", data=f"vlPage_1"))
    
    all_buttons = user_buttons + [nav_buttons] + [[Button.inline("‹ Kembali ›", "vless")]]
    
    try: await event.edit(msg, buttons=all_buttons, parse_mode='html')
    except: await event.reply(msg, buttons=all_buttons, parse_mode='html')

@bot.on(events.CallbackQuery(pattern=b"vlPage_(\d+)"))
async def paginate_vless(event):
    try: page = int(event.pattern_match.group(1).decode())
    except: page = 0
    data_list = get_vless_data()
    msg, total_pages, user_buttons = render_page_content(data_list, page, mode="list")
    nav_buttons = []
    if page > 0: nav_buttons.append(Button.inline("⏪ Prev", data=f"vlPage_{page-1}"))
    if page < total_pages - 1: nav_buttons.append(Button.inline("Next ⏩", data=f"vlPage_{page+1}"))
    all_buttons = user_buttons + [nav_buttons] + [[Button.inline("‹ Kembali ›", "vless")]]
    try: await event.edit(msg, buttons=all_buttons, parse_mode='html')
    except: await event.answer("Halaman tidak berubah")

@bot.on(events.CallbackQuery(pattern=b"vlDetail_(.+)_(.+)"))
async def detail_vless(event):
    try:
        user = event.pattern_match.group(1).decode()
        page_origin = event.pattern_match.group(2).decode()
    except: return
    try: msg_wait = await event.edit("<b>🔄 Mengambil Detail...</b>", parse_mode='html')
    except: msg_wait = await event.respond("<b>🔄 Mengambil Detail...</b>", parse_mode='html')
    try:
        cmd_path = '/usr/bin/kyt/shell/bot/bot-vless-detail' 
        if not os.path.exists(cmd_path): return await msg_wait.edit(f"❌ Script {cmd_path} tidak ditemukan.")
        subprocess.run(f"chmod +x {cmd_path}", shell=True)
        cmd = f'{cmd_path} "{user}"'
        process = subprocess.run(cmd, shell=True, check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        raw_data = process.stdout.decode("utf-8").strip()
        
        if not raw_data or "Error" in raw_data:
            await msg_wait.edit(f"❌ <b>Gagal:</b> User {user} tidak ditemukan.", buttons=[[Button.inline("‹ Kembali ›", data=f"vlPage_{page_origin}")]])
            return

        parts = raw_data.split('|')
        d_user = parts[0]
        d_domain = parts[1]
        d_uuid = parts[2]
        d_exp = parts[3]
        d_quota = parts[4]
        d_ip = parts[5]
        d_tls = parts[6]
        
        msg = f"""
<b>👤 USER DETAILS: {d_user}</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>🌐 Domain    :</b> <code>{d_domain}</code>
<b>💾 Quota     :</b> <code>{d_quota}</code>
<b>📱 IP Limit  :</b> <code>{d_ip}</code>
<b>📅 Expired   :</b> <code>{d_exp}</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>🔑 KEY CONFIGURATION</b>
<b>🆔 UUID      :</b> <code>{d_uuid}</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>🔗 LINK TLS:</b>
<code>{d_tls}</code>
"""
        buttons = [[Button.inline("‹ Kembali ke List ›", data=f"vlPage_{page_origin}")]]
        await msg_wait.edit(msg, buttons=buttons, parse_mode='html', link_preview=False)
    except Exception as e:
        await msg_wait.edit(f"<b>❌ Error:</b> {str(e)}", parse_mode='html')

@bot.on(events.CallbackQuery(data=b'delete-vless'))
async def delete_vless(event):
    sender = await event.get_sender()
    try:
        if valid(str(sender.id)) != "true": return
    except: pass
    data_list = get_vless_data()
    msg, total_pages, del_buttons = render_page_content(data_list, 0, mode="delete")
    nav_buttons = []
    if total_pages > 1: nav_buttons.append(Button.inline("Next ⏩", data=f"vlDelPage_1"))
    all_buttons = del_buttons + [nav_buttons] + [[Button.inline("‹ Kembali ›", "vless")]]
    try: await event.edit(msg, buttons=all_buttons, parse_mode='html')
    except: await event.reply(msg, buttons=all_buttons, parse_mode='html')

@bot.on(events.CallbackQuery(pattern=b"vlDelPage_(\d+)"))
async def paginate_delete_vless(event):
    try: page = int(event.pattern_match.group(1).decode())
    except: page = 0
    data_list = get_vless_data()
    msg, total_pages, del_buttons = render_page_content(data_list, page, mode="delete")
    nav_buttons = []
    if page > 0: nav_buttons.append(Button.inline("⏪ Prev", data=f"vlDelPage_{page-1}"))
    if page < total_pages - 1: nav_buttons.append(Button.inline("Next ⏩", data=f"vlDelPage_{page+1}"))
    all_buttons = del_buttons + [nav_buttons] + [[Button.inline("‹ Kembali ›", "vless")]]
    try: await event.edit(msg, buttons=all_buttons, parse_mode='html')
    except: await event.answer("Halaman tidak berubah")

@bot.on(events.CallbackQuery(pattern=b"vlDelExec_(.+)_(.+)"))
async def delete_vless_exec(event):
    try:
        user = event.pattern_match.group(1).decode()
        page = int(event.pattern_match.group(2).decode())
    except: return
    await event.answer(f"⏳ Menghapus user: {user}...", alert=False)
    cmd = f'printf "%s\n" "{user}" | bot-delvless' 
    try:
        subprocess.check_output(cmd, shell=True)
        await event.answer(f"✅ User {user} Berhasil Dihapus!", alert=True)
        data_list = get_vless_data()
        msg, total_pages, del_buttons = render_page_content(data_list, page, mode="delete")
        nav_buttons = []
        if page > 0: nav_buttons.append(Button.inline("⏪ Prev", data=f"vlDelPage_{page-1}"))
        if page < total_pages - 1: nav_buttons.append(Button.inline("Next ⏩", data=f"vlDelPage_{page+1}"))
        all_buttons = del_buttons + [nav_buttons] + [[Button.inline("‹ Kembali ›", "vless")]]
        await event.edit(msg, buttons=all_buttons, parse_mode='html')
    except Exception as e:
        await event.answer(f"❌ Gagal menghapus: {str(e)}", alert=True)