from kyt import *
from telethon import events, Button
from telethon.errors import AlreadyInConversationError
from kyt.modules import config, database, harga # Import modul penting
import subprocess
import asyncio
import math
import time
import re
import json
import base64
import requests
import datetime as DT
import os

# =================================================================
# FUNGSI PEMBANTU (HELPER)
# =================================================================

def get_vmess_data():
    """Mengambil data user VMess dari config.json dengan Filter Unique User"""
    try:
        cmd = 'grep -E "^### " "/etc/xray/config.json"'
        raw_output = subprocess.check_output(cmd, shell=True).decode("utf-8")
        data_list = []
        seen_users = set() 
        
        for line in raw_output.splitlines():
            if line.strip():
                parts = line.split()
                if len(parts) >= 3:
                    user = parts[1]
                    exp = parts[2]
                    if user not in seen_users:
                        data_list.append({"user": user, "exp": exp})
                        seen_users.add(user)
        return data_list
    except:
        return []

def render_page_content(data_list, page, mode="list", item_per_page=5):
    total_items = len(data_list)
    total_pages = math.ceil(total_items / item_per_page)
    
    if page < 0: page = 0
    if total_pages > 0 and page >= total_pages: page = total_pages - 1
    if total_pages == 0: page = 0 
    
    start = page * item_per_page
    end = start + item_per_page
    sliced_data = data_list[start:end]
    
    title = "⚡ LIST USER VMESS" if mode == "list" else "🗑️ DELETE USER VMESS"
    msg = f"<b>{title}</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
    
    flat_buttons = [] 
    
    if not sliced_data:
        msg += "<i>⚠️ Tidak ada user VMess.</i>"
    else:
        for row in sliced_data:
            user = row["user"]
            exp = row["exp"]
            
            try:
                today = DT.date.today()
                exp_dt = DT.datetime.strptime(exp, "%Y-%m-%d").date()
                diff = (exp_dt - today).days
                if diff >= 0: status = f"🟢 Active ({diff} Hari)"
                else: status = f"🔴 Expired ({abs(diff)} Hari Lalu)"
            except: status = "⚪ Unlimited"

            msg += f"""
<b>👤 User :</b> <code>{user}</code>
<b>📅 Exp  :</b> <code>{exp}</code>
<b>💎 Stat :</b> {status}
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
"""
            if mode == "list":
                flat_buttons.append(Button.inline(f"🔍 {user}", data=f"vDetail_{user}_{page}"))
            else:
                flat_buttons.append(Button.inline(f"🗑️ {user}", data=f"delExec_{user}_{page}"))

    if mode == "delete" and sliced_data:
        msg += "\n<i>Klik tombol user di bawah untuk menghapus:</i>"
        
    msg += f"\n📊 <b>Total:</b> {total_items} Users | 📄 <b>Page:</b> {page+1}/{total_pages}"
    grid_buttons = [flat_buttons[i:i + 2] for i in range(0, len(flat_buttons), 2)]
    
    return msg, total_pages, grid_buttons

# =================================================================
# HANDLER UTAMA: PROSES PEMBELIAN VMESS (USER AUTO BUY)
# =================================================================
@bot.on(events.CallbackQuery(pattern=re.compile(b"fix_buy_.*"))) 
async def buy_vmess_handler(event):
    chat = event.chat_id
    user_id = event.sender_id
    
    try:
        data_str = event.data.decode('utf-8')
        parts = data_str.split('_', 2) 
        if len(parts) < 3: return 
        
        kode_produk = parts[2]

        # 1. Cek Produk
        if kode_produk not in harga.daftar_produk:
            return 
            
        produk = harga.daftar_produk[kode_produk]
        
        # 2. FILTER KHUSUS VMESS
        kategori = str(produk.get('service', '')).upper()
        if "VMESS" not in kategori:
            return 

        # 3. Ambil Detail Harga & Spek
        try:
            harga_produk = int(str(produk['harga']).replace('.','').replace(',',''))
            masa_aktif = int(produk.get('exp', 30))
            limit_ip = int(produk.get('limit', 2))
            quota_gb = int(produk.get('quota', 0)) 
        except ValueError:
            return await event.answer("❌ Config Harga Error", alert=True)

        # 4. Cek Saldo
        saldo_user = database.get_saldo(user_id)
        if saldo_user < harga_produk:
            kurang = harga_produk - saldo_user
            msg_kurang = f"❌ SALDO TIDAK CUKUP!\n\n💰 Harga: Rp {harga_produk:,}\n💳 Saldo: Rp {saldo_user:,}\n📉 Kurang: Rp {kurang:,}\n\nSilakan Topup dulu."
            return await event.answer(msg_kurang, alert=True)

        # 5. Lanjut Buat Akun
        await event.answer("✅ Saldo Cukup. Memproses...", alert=False)
        await event.delete() 
        
        async with bot.conversation(chat, timeout=60) as conv:
            # =====================================================
            # BAGIAN PERBAIKAN: MENGGUNAKAN ASYNCIO.WAIT
            # =====================================================
            ask_msg = await conv.send_message(
                f"<b>👤 Masukkan Username VMess Baru:</b>\n(Ketik nama atau klik tombol batal)", 
                buttons=[[Button.inline("❌ Batal / Kembali", "cancel_buy")]], 
                parse_mode='html'
            )
            
            # Buat 2 Task: Menunggu Chat text ATAU Menunggu Klik Tombol
            task_text = conv.wait_event(events.NewMessage(incoming=True, from_users=user_id))
            task_click = conv.wait_event(events.CallbackQuery(data=b'cancel_buy'))

            # Tunggu mana yang selesai duluan
            done, pending = await asyncio.wait([task_text, task_click], return_when=asyncio.FIRST_COMPLETED)

            # Batalkan task yang belum selesai (agar tidak nyangkut di memori)
            for p in pending:
                p.cancel()

            # Ambil hasil dari task yang selesai
            response = list(done)[0].result()
            
            # Cek apakah respon adalah Event Callback (Tombol)
            if isinstance(response, events.CallbackQuery.Event):
                await ask_msg.delete()
                return await conv.send_message("❌ Pembelian Dibatalkan.", buttons=[[Button.inline("‹ Kembali Menu ›", "menu_as_user")]])
            
            # Jika respon adalah Pesan Text (Username)
            user_msg = response
            username = user_msg.raw_text.strip()
            await ask_msg.delete() # Hapus pesan tanya agar rapi

            # Cek manual command cancel text
            if username == '/cancel':
                return await conv.send_message("❌ Pembelian Dibatalkan.", buttons=[[Button.inline("‹ Kembali ›", "menu_as_user")]])
            
            # Validasi Username (Regex)
            if not re.match("^[a-zA-Z0-9]+$", username):
                 return await conv.send_message("❌ <b>Username Invalid!</b> Gunakan hanya huruf dan angka.", buttons=[[Button.inline("‹ Ulangi ›", "menu_as_user")]], parse_mode='html')

            # Cek User di VPS
            try:
                cmd_cek = f'grep -w "### {username}" /etc/xray/config.json'
                subprocess.check_output(cmd_cek, shell=True)
                return await conv.send_message(f"❌ <b>Username '{username}' sudah ada!</b>\nSilakan ulangi dengan nama lain.", buttons=[[Button.inline("‹ Kembali ›", "menu_as_user")]], parse_mode='html')
            except: pass

            # =====================================================
            # EKSEKUSI PEMBELIAN
            # =====================================================
            msg_proc = await conv.send_message("🔄 <b>Sedang membuat akun...</b>", parse_mode='html')
            
            if database.kurang_saldo(user_id, harga_produk, f"Beli {produk['nama']}"):
                try:
                    # Eksekusi Script
                    cmd = f'printf "%s\n" "{username}" "{masa_aktif}" "{quota_gb}" "{limit_ip}" | addws-bot'
                    
                    raw_out = subprocess.check_output(cmd, shell=True).decode("utf-8")
                    
                    links = [x.group() for x in re.finditer("vmess://(.*)", raw_out)]
                    if not links: raise Exception("Gagal mendapatkan Link VMess")
                    
                    z = base64.b64decode(links[0].replace("vmess://","")).decode("ascii")
                    d = json.loads(z)
                    
                    link_tls  = links[0].strip()
                    link_ntls = links[1].strip() if len(links) > 1 else "-"
                    link_grpc = links[2].strip() if len(links) > 2 else "-"
                    
                    sisa_saldo = database.get_saldo(user_id)
                    quota_str = "Unlimited" if quota_gb == 0 else f"{quota_gb} GB"
                    today = DT.date.today()
                    later = today + DT.timedelta(days=masa_aktif)
                    exp_date_str = later.strftime("%Y-%m-%d")
                    gen_date = today.strftime("%d/%m/%Y")

                    msg_sukses = f"""
<b>⚡ PREMIUM VMESS ACCOUNT ⚡</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>👤 ACCOUNT INFO</b>
<b>🏷️ Username :</b> <code>{username}</code>
<b>🌐 Domain   :</b> <code>{d["add"]}</code>
<b>🔑 UUID     :</b> <code>{d["id"]}</code>
<b>🛡️ AlterID  :</b> <code>0</code>
<b>⚙️ Network  :</b> <code>WS / GRPC</code>

<b>🔌 PORT SETTINGS</b>
<b>🟢 TLS  :</b> <code>443</code>  |  <b>🔴 None :</b> <code>80</code>
<b>🔵 GRPC :</b> <code>443</code>

<b>🛣️ PATH (WS / GRPC)</b>
<code>{d["path"]}</code> / <code>{d.get("serviceName", "vmess-grpc")}</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>🔗 CONNECTION LINKS</b>
<i>(Klik link untuk menyalin)</i>

<b>🔮 VMESS TLS (SSL)</b>
<code>{link_tls}</code>

<b>🔮 VMESS NON-TLS</b>
<code>{link_ntls}</code>

<b>🔮 VMESS GRPC</b>
<code>{link_grpc}</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>📊 SUBSCRIPTION STATUS</b>
<b>📅 Expired  :</b> <code>{exp_date_str}</code>
<b>📵 IP Limit :</b> <code>{limit_ip} Device</code>
<b>💾 Quota    :</b> <code>{quota_str}</code>

<b>🧾 TRANSACTION RECEIPT</b>
<b>💰 Harga    :</b> Rp {harga_produk:,}
<b>💳 Saldo    :</b> Rp {sisa_saldo:,}
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<i>Generated on {gen_date}</i>
========================================
<i>🚀 Thanks for using our service!</i>
"""
                    await msg_proc.edit(msg_sukses, parse_mode='html', link_preview=False, buttons=[[Button.inline("‹ Kembali ke Menu ›", "menu_as_user")]])
                    
                except Exception as e:
                    database.tambah_saldo(user_id, harga_produk, "REFUND: Gagal System")
                    await msg_proc.edit(f"❌ <b>Gagal System:</b> {str(e)}\nSaldo telah dikembalikan.", parse_mode='html')
            else:
                await msg_proc.edit("❌ <b>Transaksi Gagal:</b> Saldo tidak cukup.", parse_mode='html')

    except AlreadyInConversationError:
        await event.answer("⚠️ Selesaikan proses sebelumnya!", alert=True)
    except asyncio.TimeoutError:
        await event.respond("❌ <b>Waktu Habis.</b>", buttons=[[Button.inline("‹ Kembali ›", "menu_as_user")]], parse_mode='html')
    except Exception as e:
        await event.respond(f"❌ <b>System Error:</b> {str(e)}", parse_mode='html')

# =================================================================
# 1. MENU UTAMA VMESS (ADMIN)
# =================================================================
@bot.on(events.CallbackQuery(data=b'vmess'))
async def vmess_menu(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true": return await event.answer("Access Denied", alert=True)

    try:
        try: my_domain = DOMAIN
        except: my_domain = "Premium Server"

        msg = f"""
<b>⚡ VMESS MANAGER</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>🟢 Service Status :</b> <code>Active</code>
<b>🌐 Hostname/IP    :</b> <code>{my_domain}</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>» 👤 Telegram Admin : @HookageLegend</b>
"""
        inline = [
            [Button.inline("⚡ TRIAL", "trial-vmess"), Button.inline("⚡ CREATE", "create-vmess")],
            [Button.inline("📊 LIST USER", "list-vmess"), Button.inline("🗑️ DELETE", "delete-vmess")],
            [Button.inline("‹ Main Menu ›", "menu")]
        ]
        
        await event.edit(msg, buttons=inline, parse_mode='html')
    except Exception as e:
        await event.respond(f"Error Menu: {str(e)}")

# =================================================================
# 2. CREATE VMESS (ADMIN MANUAL) - DENGAN TOMBOL KEMBALI
# =================================================================
@bot.on(events.CallbackQuery(data=b'create-vmess'))
async def create_vmess(event):
    chat = event.chat_id
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true": return await event.answer("Akses Ditolak", alert=True)

    async def create_vmess_process(event):
        try:
            async with bot.conversation(chat, timeout=60) as conv:
                # -----------------------------------------------------------
                # STEP 1: INPUT USERNAME (MODIFIKASI DISINI)
                # -----------------------------------------------------------
                # Kita kirim pesan dengan tombol
                ask_msg = await conv.send_message(
                    '<b>👤 Input Username:</b>\n(Ketik nama atau klik tombol batal)',
                    buttons=[[Button.inline("❌ Batal / Kembali", "cancel_create")]],
                    parse_mode='html'
                )

                # Kita tunggu: Apakah user mengirim TEXT atau klik TOMBOL?
                response = await conv.wait_event(
                    events.NewMessage(incoming=True, from_users=sender.id) |
                    events.CallbackQuery(data=b'cancel_create')
                )

                # Cek tipe responnya
                if isinstance(response, events.CallbackQuery.Event):
                    # Jika user klik tombol Batal
                    await ask_msg.delete() # Hapus pesan tanya
                    return await event.respond("❌ <b>Pembuatan Dibatalkan.</b>", buttons=[[Button.inline("‹ Menu VMess ›", "vmess")]], parse_mode='html')
                else:
                    # Jika user mengirim Teks (Username)
                    user = response.raw_text.strip()
                    # Hapus pesan tanya agar rapi (opsional)
                    await ask_msg.delete() 
                    
                    if user == '/cancel': 
                        return await event.respond("❌ Dibatalkan.", buttons=[[Button.inline("‹ Menu VMess ›", "vmess")]])

                # -----------------------------------------------------------
                # STEP 2: INPUT QUOTA
                # -----------------------------------------------------------
                await event.respond("<b>💾 Input Quota (GB):</b>\n(0 = Unlimited)", parse_mode='html')
                quota_msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                quota = quota_msg.raw_text.strip()

                # -----------------------------------------------------------
                # STEP 3: INPUT IP LIMIT
                # -----------------------------------------------------------
                await event.respond("<b>📱 Input IP Limit (Angka):</b>", parse_mode='html')
                ip_msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                iplimit = ip_msg.raw_text.strip()
            
                # -----------------------------------------------------------
                # STEP 4: INPUT EXPIRED
                # -----------------------------------------------------------
                await event.respond("<b>📅 Input Expired (Hari):</b>", parse_mode='html')
                exp_msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                exp = exp_msg.raw_text.strip()

            # -----------------------------------------------------------
            # EKSEKUSI PEMBUATAN AKUN
            # -----------------------------------------------------------
            msg_load = await event.respond("<code>Processing...</code>", parse_mode='html')
            
            # Eksekusi script backend
            cmd = f'printf "%s\n" "{user}" "{exp}" "{quota}" "{iplimit}" | addws-bot'
            
            try:
                raw_out = subprocess.check_output(cmd, shell=True).decode("utf-8")
                
                # Parsing regex vmess://
                links = [x.group() for x in re.finditer("vmess://(.*)", raw_out)]
                if not links: raise Exception("Link tidak ditemukan (Script Error)")
                
                # Decode Vmess JSON untuk info detail
                z = base64.b64decode(links[0].replace("vmess://","")).decode("ascii")
                d = json.loads(z)
                
                link_tls  = links[0].strip()
                link_ntls = links[1].strip() if len(links) > 1 else "-"
                link_grpc = links[2].strip() if len(links) > 2 else "-"
                
                today = DT.date.today()
                later = today + DT.timedelta(days=int(exp))
                exp_date_str = later.strftime("%Y-%m-%d")
                gen_date = today.strftime("%d/%m/%Y")
                quota_str = "Unlimited" if quota == '0' else f"{quota} GB"
                
                msg = f"""
<code>========================================
 AKUN VMESS PREMIUM
========================================

 INFORMASI AKUN
Username: {user}
Domain: {d["add"]}
Port TLS: 443
Port None: 80
Port GRPC: 443
UUID: {d["id"]}
AlterID: 0
Network: WS / GRPC
Path: {d["path"]} / {d.get("serviceName", "vmess-grpc")}

 FORMAT KONEKSI
TLS: {link_tls}

NON-TLS: {link_ntls}

GRPC: {link_grpc}

 INFORMASI TAMBAHAN
Expired: {exp_date_str}
IP Limit: {iplimit} Device
Quota: {quota_str}

========================================
ᵗᵉʳⁱᵐᵃᵏᵃˢⁱʰ ᵗᵉˡᵃʰ ᵐᵉⁿᵍᵍᵘⁿᵃᵏᵃⁿ ˡᵃʸᵃⁿᵃⁿ ᵏᵃᵐⁱ
Generated on {gen_date}
========================================</code>
"""
                await msg_load.edit(msg, parse_mode='html', link_preview=False, buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
            except Exception as e:
                await msg_load.edit(f"<b>❌ Error:</b> {str(e)}", buttons=[[Button.inline("‹ Kembali ›", "menu")]], parse_mode='html')
                
        except asyncio.TimeoutError:
            await event.respond("<b>❌ Waktu Habis</b>", parse_mode='html')
        except Exception as e:
            await event.respond(f"<b>❌ Error:</b> {str(e)}", parse_mode='html')

    await create_vmess_process(event)

# =================================================================
# 3. TRIAL VMESS
# =================================================================
@bot.on(events.CallbackQuery(data=b'trial-vmess'))
async def trial_vmess(event):
    chat = event.chat_id
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true": return await event.answer("Akses Ditolak", alert=True)

    async def trial_vmess_process(event):
        try:
            async with bot.conversation(chat, timeout=60) as conv:
                await event.respond("<b>⏱️ Input Durasi Trial (Menit):</b>\n<i>Contoh: 30</i>", parse_mode='html')
                resp = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                exp = resp.raw_text.strip()
                if not exp.isdigit(): return await event.respond("❌ Angka saja.")
            
            msg_load = await event.respond("<code>Creating Trial...</code>", parse_mode='html')
            cmd = f'printf "%s\n" "{exp}" | bot-trialws'
            
            try:
                raw_out = subprocess.check_output(cmd, shell=True).decode("utf-8")
                links = [x.group() for x in re.finditer("vmess://(.*)", raw_out)]
                
                z = base64.b64decode(links[0].replace("vmess://","")).decode("ascii")
                d = json.loads(z)

                link_tls  = links[0].strip()
                link_ntls = links[1].strip() if len(links) > 1 else ""
                link_grpc = links[2].strip() if len(links) > 2 else ""

                msg = f"""
<code>========================================
 AKUN VMESS TRIAL
========================================

 Username: {d["ps"]}
 Expired : {exp} Menit
 Domain  : {d["add"]}
 UUID    : {d["id"]}

 TLS: {link_tls}

 NON-TLS: {link_ntls}

 GRPC: {link_grpc}
========================================</code>
"""
                await msg_load.edit(msg, parse_mode='html', link_preview=False, buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
            except: 
                await msg_load.edit(f"❌ Gagal generate trial.", parse_mode='html')
                
        except Exception as e:
            await event.respond(f"Error System: {e}")

    await trial_vmess_process(event)

# =================================================================
# 4. LIST & DELETE & DETAIL (SAMA SEPERTI SEBELUMNYA)
# =================================================================
@bot.on(events.CallbackQuery(data=b'list-vmess'))
async def list_vmess_handler(event):
    if valid(str(event.sender_id)) != "true": return
    data = get_vmess_data()
    msg, total, btns = render_page_content(data, 0, "list")
    nav = []
    if total > 1: nav.append(Button.inline("Next ⏩", "vmessPage_1"))
    all_btns = btns + [nav] + [[Button.inline("‹ Kembali ›", "vmess")]]
    await event.edit(msg, buttons=all_btns, parse_mode='html')

@bot.on(events.CallbackQuery(pattern=b"vmessPage_(\d+)"))
async def paginate_vmess(event):
    page = int(event.pattern_match.group(1).decode())
    data = get_vmess_data()
    msg, total, btns = render_page_content(data, page, "list")
    nav = []
    if page > 0: nav.append(Button.inline("⏪ Prev", f"vmessPage_{page-1}"))
    if page < total - 1: nav.append(Button.inline("Next ⏩", f"vmessPage_{page+1}"))
    all_btns = btns + [nav] + [[Button.inline("‹ Kembali ›", "vmess")]]
    await event.edit(msg, buttons=all_btns, parse_mode='html')

@bot.on(events.CallbackQuery(pattern=b"vDetail_(.+)_(.+)"))
async def detail_vmess(event):
    user = event.pattern_match.group(1).decode()
    page = event.pattern_match.group(2).decode()
    msg_wait = await event.edit("🔄 Loading...", parse_mode='html')
    
    try:
        cmd = f'/usr/bin/kyt/shell/bot/bot-vmess-detail "{user}"'
        if not os.path.exists(cmd.split()[0]): return await msg_wait.edit("❌ Script detail 404")
        
        proc = subprocess.run(cmd, shell=True, stdout=subprocess.PIPE)
        raw = proc.stdout.decode("utf-8").strip()
        parts = raw.split('|')
        
        if len(parts) < 7: return await msg_wait.edit("❌ Data Corrupt")
        
        msg = f"""
<b>👤 USER DETAILS: {parts[0]}</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>🌐 Domain    :</b> <code>{parts[1]}</code>
<b>💾 Quota     :</b> <code>{parts[4]}</code>
<b>📱 IP Limit  :</b> <code>{parts[5]}</code>
<b>📅 Expired   :</b> <code>{parts[3]}</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>🆔 UUID      :</b> <code>{parts[2]}</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>🔮 TLS  :</b> <code>{parts[6]}</code>

<b>🔮 NTLS :</b> <code>{parts[7] if len(parts)>7 else "-"}</code>

<b>🔮 GRPC :</b> <code>{parts[8] if len(parts)>8 else "-"}</code>
"""
        await msg_wait.edit(msg, buttons=[[Button.inline("‹ Kembali ›", f"vmessPage_{page}")]], parse_mode='html', link_preview=False)
    except Exception as e:
        await msg_wait.edit(f"Error: {e}")

@bot.on(events.CallbackQuery(data=b'delete-vmess'))
async def delete_vmess(event):
    if valid(str(event.sender_id)) != "true": return
    data = get_vmess_data()
    msg, total, btns = render_page_content(data, 0, "delete")
    nav = []
    if total > 1: nav.append(Button.inline("Next ⏩", "delPage_1"))
    all_btns = btns + [nav] + [[Button.inline("‹ Kembali ›", "vmess")]]
    await event.edit(msg, buttons=all_btns, parse_mode='html')

@bot.on(events.CallbackQuery(pattern=b"delPage_(\d+)"))
async def paginate_delete_vmess(event):
    page = int(event.pattern_match.group(1).decode())
    data = get_vmess_data()
    msg, total, btns = render_page_content(data, page, "delete")
    nav = []
    if page > 0: nav.append(Button.inline("⏪ Prev", f"delPage_{page-1}"))
    if page < total - 1: nav.append(Button.inline("Next ⏩", f"delPage_{page+1}"))
    all_btns = btns + [nav] + [[Button.inline("‹ Kembali ›", "vmess")]]
    await event.edit(msg, buttons=all_btns, parse_mode='html')

@bot.on(events.CallbackQuery(pattern=b"delExec_(.+)_(.+)"))
async def delete_vmess_exec(event):
    user = event.pattern_match.group(1).decode()
    page = int(event.pattern_match.group(2).decode())
    
    await event.answer(f"⏳ Deleting {user}...", alert=False)
    subprocess.run(f'printf "%s\n" "{user}" | bot-delws', shell=True)
    await event.answer(f"✅ Deleted!", alert=True)
    
    data = get_vmess_data()
    msg, total, btns = render_page_content(data, page, "delete")
    nav = []
    if page > 0: nav.append(Button.inline("⏪ Prev", f"delPage_{page-1}"))
    if page < total - 1: nav.append(Button.inline("Next ⏩", f"delPage_{page+1}"))
    all_btns = btns + [nav] + [[Button.inline("‹ Kembali ›", "vmess")]]
    await event.edit(msg, buttons=all_btns, parse_mode='html')