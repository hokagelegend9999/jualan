from kyt import *
import subprocess
import asyncio
import math
import time
import random
import requests
import datetime as DT
import os
import re
from telethon.tl.custom import Button
from telethon import events
from telethon.errors import AlreadyInConversationError

# --- IMPORT MODULE TAMBAHAN ---
from kyt.modules import config, database, harga

# =================================================================
# 1. KONFIGURASI DOMAIN (ANTI-CRASH)
# =================================================================
DOMAIN = "IP-VPS" 
try:
    if hasattr(config, 'DOMAIN'): DOMAIN = config.DOMAIN
    elif os.path.exists("/etc/xray/domain"):
        with open("/etc/xray/domain", "r") as f: DOMAIN = f.read().strip()
    elif os.path.exists("/root/domain"):
        with open("/root/domain", "r") as f: DOMAIN = f.read().strip()
except: pass

# =================================================================
# 2. FUNGSI PEMBANTU (HELPER)
# =================================================================

def get_ssh_users_detailed():
    """Mengambil semua user SSH sistem (UID >= 1000) beserta detailnya."""
    users_data = []
    try:
        with open("/etc/passwd", "r") as f:
            for line in f:
                parts = line.split(":")
                if len(parts) > 2:
                    user = parts[0]; uid = int(parts[2])
                    if uid >= 1000 and user != "nobody":
                        try:
                            cmd_exp = f"chage -l {user} | grep 'Account expires' | cut -d: -f2"
                            exp_raw = subprocess.check_output(cmd_exp, shell=True).decode().strip()
                            exp_fmt = "Unlimited" if "never" in exp_raw else exp_raw
                        except: exp_fmt = "-"
                        try:
                            cmd_stat = f"passwd -S {user} | awk '{{print $2}}'"
                            stat_code = subprocess.check_output(cmd_stat, shell=True).decode().strip()
                            status_icon = "🔴 Locked" if stat_code == "L" else "🟢 Active"
                        except: status_icon = "⚪ Unknown"
                        users_data.append({"user": user, "exp": exp_fmt, "status": status_icon})
    except: pass
    return sorted(users_data, key=lambda x: x['user'])

def render_ssh_interface(page, is_delete_mode=False):
    """Render UI untuk List dan Delete (Prefix Tombol: ZIVPN_SSH_...)"""
    data = get_ssh_users_detailed()
    items_per_page = 5
    total_pages = math.ceil(len(data) / items_per_page)
    
    if total_pages == 0:
        return "<b>☁️ SSH MANAGER</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n<i>⚠️ Tidak ada user SSH.</i>", [[Button.inline("🔙 KEMBALI", data="ssh")]]

    if page >= total_pages: page = total_pages - 1
    if page < 0: page = 0

    start = page * items_per_page
    end = start + items_per_page
    sliced_data = data[start:end]

    title = "🗑️ <b>DELETE USER SSH</b>" if is_delete_mode else "📊 <b>LIST USER SSH</b>"
    msg = f"{title}\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
    msg += f"<b>👥 Total:</b> {len(data)} Users | <b>📄 Page:</b> {page + 1}/{total_pages}\n"
    msg += f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"

    for i, user in enumerate(sliced_data):
        msg += f"<b>{start + i + 1}.</b> 👤 <code>{user['user']}</code>\n"
        msg += f"   📅 {user['exp']} | {user['status']}\n───────────────────\n"

    buttons = []
    if is_delete_mode:
        msg += f"\n<i>👇 Klik tombol nama user untuk menghapus.</i>"
        row = []
        for user in sliced_data:
            # PREFIX UNIK AGAR TIDAK BENTROK DENGAN VMESS
            row.append(Button.inline(f"❌ {user['user']}", data=f"ZIVPN_SSH_ASK_{user['user']}_{page}"))
            if len(row) == 2: buttons.append(row); row = []
        if row: buttons.append(row)

    nav = []
    # PREFIX UNIK UNTUK PAGINATION
    prefix = "ZIVPN_SSH_DEL_PG" if is_delete_mode else "ZIVPN_SSH_LIST_PG"
    
    if page > 0: nav.append(Button.inline("⏪ Prev", data=f"{prefix}_{page-1}"))
    if page < total_pages - 1: nav.append(Button.inline("Next ⏩", data=f"{prefix}_{page+1}"))
    if nav: buttons.append(nav)
    
    buttons.append([Button.inline("🔙 KEMBALI KE MENU", data="ssh")])
    return msg, buttons

def get_ssh_monitor_data():
    """Monitor Login Akurat"""
    online_users = {}
    all_ssh_users = []
    try:
        with open("/etc/passwd", "r") as f:
            for line in f:
                parts = line.split(":")
                if len(parts) > 6:
                    u, uid = parts[0], int(parts[2])
                    if uid >= 1000 and u != "nobody": all_ssh_users.append(u)
        ps_out = subprocess.getoutput("ps aux")
        for line in ps_out.splitlines():
            for u in all_ssh_users:
                if re.search(rf"[\s\[\"']{u}[\s\]\"']", line):
                    if "dropbear" in line: online_users[u] = "Dropbear"
                    elif "sshd" in line: online_users[u] = "OpenSSH"
                    elif "python" in line or "ws" in line: online_users[u] = "SSH-WS"
        msg = "<b>⚡ HOKAGE MONITORING ⚡</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n"
        msg += "<b>🟢 [ USER ONLINE ]</b>\n"
        count_on = 0
        for u in sorted(online_users.keys()):
            count_on += 1
            msg += f" ● 👤 <code>{u:12}</code> ⚡ ({online_users[u]})\n"
        if count_on == 0: msg += " <i>(Tidak ada user online)</i>\n"
        msg += "\n<b>🔴 [ USER OFFLINE ]</b>\n"
        count_off = 0
        for u in sorted(all_ssh_users):
            if u not in online_users:
                count_off += 1
                msg += f" ● 👤 <code>{u:12}</code> (Offline)\n"
        msg += "\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        msg += f"📊 <b>Total:</b> {len(all_ssh_users)} | <b>ON:</b> {count_on} | <b>OFF:</b> {count_off}"
        return msg
    except Exception as e: return f"❌ Error Scan: {str(e)}"

# =================================================================
# 3. HANDLER LIST (SHOW)
# =================================================================
@bot.on(events.CallbackQuery(data=b'show-ssh'))
async def show_list_menu(event):
    if str(event.sender_id) != config.OWNER_ID and valid(str(event.sender_id)) != "true": return
    msg, btns = render_ssh_interface(0, is_delete_mode=False)
    await event.edit(msg, buttons=btns, parse_mode='html')

@bot.on(events.CallbackQuery(pattern=b'ZIVPN_SSH_LIST_PG_(\d+)'))
async def show_list_pagination(event):
    page = int(event.pattern_match.group(1).decode())
    msg, btns = render_ssh_interface(page, is_delete_mode=False)
    try: await event.edit(msg, buttons=btns, parse_mode='html')
    except: await event.answer("Halaman tidak berubah")

# =================================================================
# 4. HANDLER DELETE (DELETE) - PREFIX UNIK 'ZIVPN_SSH_'
# =================================================================
@bot.on(events.CallbackQuery(data=b'delete-ssh'))
async def delete_menu(event):
    sender = await event.get_sender()
    if str(sender.id) != config.OWNER_ID and valid(str(sender.id)) != "true": return await event.answer("Akses Ditolak", alert=True)
    msg, btns = render_ssh_interface(0, is_delete_mode=True)
    await event.edit(msg, buttons=btns, parse_mode='html')

@bot.on(events.CallbackQuery(pattern=b'ZIVPN_SSH_DEL_PG_(\d+)'))
async def delete_pagination(event):
    page = int(event.pattern_match.group(1).decode())
    msg, btns = render_ssh_interface(page, is_delete_mode=True)
    try: await event.edit(msg, buttons=btns, parse_mode='html')
    except: pass

@bot.on(events.CallbackQuery(pattern=b'ZIVPN_SSH_ASK_(.+)_(.+)'))
async def delete_confirm(event):
    user = event.pattern_match.group(1).decode(); page = event.pattern_match.group(2).decode()
    msg = f"<b>⚠️ KONFIRMASI HAPUS</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n👤 <b>User:</b> <code>{user}</code>\n\n<i>Yakin hapus permanen?</i>"
    buttons = [[Button.inline("✅ YA, HAPUS", data=f"ZIVPN_SSH_EXEC_{user}_{page}")], [Button.inline("❌ BATAL", data=f"ZIVPN_SSH_DEL_PG_{page}")]]
    await event.edit(msg, buttons=buttons, parse_mode='html')

@bot.on(events.CallbackQuery(pattern=b'ZIVPN_SSH_EXEC_(.+)_(.+)'))
async def delete_execute(event):
    user = event.pattern_match.group(1).decode(); page = int(event.pattern_match.group(2).decode())
    await event.answer(f"⏳ Menghapus {user}...", alert=False)
    
    try:
        # 1. HAPUS DARI SYSTEM (LINUX USER)
        subprocess.run(f"userdel -f {user}", shell=True)
        subprocess.run(f"sed -i '/^{user} hard/d' /etc/security/limits.conf", shell=True)
        
        # 2. HAPUS DARI USER-DB (SAFE JQ)
        cmd_db = f"jq --arg u '{user}' 'del(.[$u])' /etc/zivpn/user-db.json > /tmp/db && mv /tmp/db /etc/zivpn/user-db.json"
        subprocess.run(cmd_db, shell=True)
        
        # 3. HAPUS DARI CONFIG (ARRAY) - OPTIONAL (CATCH ERROR)
        try:
            cmd_conf = f"jq --arg u '{user}' '.auth.config -= [$u]' /etc/zivpn/config.json > /tmp/conf && mv /tmp/conf /etc/zivpn/config.json"
            subprocess.run(cmd_conf, shell=True)
        except: pass
        
        # 4. RESTART SERVICE
        subprocess.run("systemctl restart zivpn", shell=True)

        await event.answer(f"✅ User {user} dihapus.", alert=True)
        
        # 5. KEMBALI KE LIST SSH (BUKAN VMESS)
        msg, btns = render_ssh_interface(page, is_delete_mode=True)
        await event.edit(msg, buttons=btns, parse_mode='html')
        
    except Exception as e: 
        await event.answer(f"❌ Gagal: {e}", alert=True)

# =================================================================
# 5. CREATE SSH (ADMIN) - TOMBOL BATAL & OUTPUT PREMIUM
# =================================================================
@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
    chat = event.chat_id; sender = await event.get_sender()
    if str(sender.id) != config.OWNER_ID and valid(str(sender.id)) != "true": return await event.answer("Akses Ditolak", alert=True)

    async def create_proc():
        try:
            async with bot.conversation(chat, timeout=120) as conv:
                q1 = await conv.send_message('<b>👤 Masukkan Username:</b>', parse_mode='html', buttons=[[Button.inline("❌ Batal", "abort_create")]])
                
                # FIX WAIT EVENT (Asyncio Wait)
                event_msg = conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                event_btn = conv.wait_event(events.CallbackQuery(pattern=b'abort_create'))
                done, pending = await asyncio.wait([event_msg, event_btn], return_when=asyncio.FIRST_COMPLETED)
                for task in pending: task.cancel()
                
                resp1 = list(done)[0].result()
                if isinstance(resp1, events.CallbackQuery.Event):
                    await resp1.answer("Dibatalkan"); await q1.delete()
                    return await conv.send_message("❌ Pembuatan akun dibatalkan.", buttons=[[Button.inline("‹ Menu ›", "menu")]])
                
                user = resp1.raw_text.strip()
                if not re.match("^[a-zA-Z0-9]+$", user): return await conv.send_message("❌ Invalid format.", buttons=[[Button.inline("‹ Menu ›", "menu")]])

                await conv.send_message("<b>🔑 Password:</b>", parse_mode='html')
                pw = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text.strip()
                
                await conv.send_message("<b>📱 Max Login:</b>", parse_mode='html')
                limit = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text.strip()
                
                await conv.send_message("<b>💾 Quota (GB):</b> (0=Unl)", parse_mode='html')
                quota = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text.strip()
                
                await conv.send_message("<b>📅 Masa Aktif (Hari):</b>", parse_mode='html')
                exp = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text.strip()

            msg_load = await event.respond("Creating...", parse_mode='html')
            
            cmd = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{user}:{pw}" | chpasswd && echo "{user} hard maxlogins {limit}" >> /etc/security/limits.conf'
            try:
                subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT)
                
                today = DT.date.today(); later = today + DT.timedelta(days=int(exp))
                exp_date_str = later.strftime("%Y-%m-%d")
                quota_str = "Unlimited" if quota == '0' else f"{quota} GB"
                gen_date = today.strftime("%d/%m/%Y")
                
                cmd_zivpn = f"""jq --arg u "{user}" '.auth.config += [$u]' /etc/zivpn/config.json > /tmp/c && mv /tmp/c /etc/zivpn/config.json && jq --arg u "{user}" --arg e "{exp_date_str}" --arg i "{limit}" --arg q "{quota}" '.[$u] = {{exp: $e, ip: $i, quota: $q}}' /etc/zivpn/user-db.json > /tmp/d && mv /tmp/d /etc/zivpn/user-db.json && systemctl restart zivpn"""
                subprocess.run(cmd_zivpn, shell=True)
                
                msg_done = f"""
<code>⚡ PREMIUM SSH & ZIVPN ACCOUNT ⚡
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
 ☁️ INFORMASI AKUN SSH & ZIVPN
👤 Username : {user}
🔑 Password : {pw}
🌐 Domain   : {DOMAIN}
📅 Expired  : {exp_date_str}
📱 Limit IP : {limit} Device
💾 Quota    : {quota_str}
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
 🔌 SSH WS   : 80
 🛡️ SSH SSL  : 443
 🔮 UDP GW   : 1-65535
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
 🔗 FORMAT KONEKSI

• WS Format:
{DOMAIN}:80@{user}:{pw}

• TLS Format:
{DOMAIN}:443@{user}:{pw}

• UDP Format:
{DOMAIN}:1-65535@{user}:{pw}

• ZIVPN Format:
UDP SERVER: {DOMAIN} UDP PASSWORD: {user}
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
ᵗᵉʳⁱᵐᵃᵏᵃˢⁱʰ ᵗᵉˡᵃʰ ᵐᵉⁿᵍᵍᵘⁿᵃᵏᵃⁿ ˡᵃʸᵃⁿᵃⁿ ᵏᵃᵐⁱ
Generated on {gen_date}
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬</code>
"""
                await msg_load.edit(msg_done, buttons=[[Button.inline("‹ Menu ›", "menu")]], parse_mode='html')
            
            except subprocess.CalledProcessError as e:
                if e.returncode == 9:
                    await msg_load.edit(f"⚠️ <b>Gagal:</b> Username '{user}' sudah ada!", buttons=[[Button.inline("↻ Ulangi", "create-ssh")], [Button.inline("‹ Menu ›", "menu")]], parse_mode='html')
                else:
                    await msg_load.edit(f"❌ <b>Error System:</b> {e.output.decode()}", buttons=[[Button.inline("‹ Menu ›", "menu")]], parse_mode='html')
                    
        except Exception as e: await event.respond(f"Error: {e}")
    await create_proc()

# =================================================================
# 6. HANDLER AUTO BUY (USER) - ICON PREMIUM
# =================================================================
@bot.on(events.CallbackQuery(pattern=re.compile(b"fix_buy_.*"))) 
async def buy_process_handler(event):
    chat = event.chat_id; user_id = event.sender_id
    try:
        data_str = event.data.decode('utf-8'); parts = data_str.split('_', 2) 
        if len(parts) < 3: return
        kode_produk = parts[2]
        if kode_produk not in harga.daftar_produk: return
        produk = harga.daftar_produk[kode_produk]
        if "SSH" not in str(produk.get('service', '')).upper(): return

        harga_produk = int(str(produk['harga']).replace('.','').replace(',',''))
        masa_aktif = int(produk.get('exp', 30))
        limit_ip = int(produk.get('limit', 2))
        quota_gb = int(produk.get('quota', 0))

        if database.get_saldo(user_id) < harga_produk:
            return await event.answer(f"❌ SALDO TIDAK CUKUP", alert=True)

        await event.answer("✅ Memproses...", alert=False); await event.delete() 
        
        async with bot.conversation(chat, timeout=60) as conv:
            q1 = await conv.send_message(f"<b>👤 Masukkan Username Baru:</b>", parse_mode='html', buttons=[[Button.inline("❌ Batal", "abort_buy")]])
            
            event_msg = conv.wait_event(events.NewMessage(incoming=True, from_users=user_id))
            event_btn = conv.wait_event(events.CallbackQuery(pattern=b'abort_buy'))
            
            done, pending = await asyncio.wait([event_msg, event_btn], return_when=asyncio.FIRST_COMPLETED)
            for task in pending: task.cancel()
            
            resp1 = list(done)[0].result()
            if isinstance(resp1, events.CallbackQuery.Event):
                await resp1.answer("Dibatalkan"); await q1.delete()
                return await conv.send_message("❌ Transaksi dibatalkan.", buttons=[[Button.inline("‹ Menu ›", "menu_as_user")]])

            username = resp1.raw_text.strip()
            if not re.match("^[a-zA-Z0-9]+$", username): return await conv.send_message("❌ Username Invalid.")

            await conv.send_message(f"<b>🔑 Masukkan Password:</b>", parse_mode='html')
            pass_msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=user_id))
            password = pass_msg.raw_text.strip()

            msg_proc = await conv.send_message("🔄 <b>Sedang Membuat Akun...</b>", parse_mode='html')
            
            if database.kurang_saldo(user_id, harga_produk, f"Beli {produk['nama']}"):
                try:
                    cmd_sys = f'useradd -e `date -d "{masa_aktif} days" +"%Y-%m-%d"` -s /bin/false -M {username} && echo "{username}:{password}" | chpasswd && echo "{username} hard maxlogins {limit_ip}" >> /etc/security/limits.conf'
                    subprocess.check_output(cmd_sys, shell=True, stderr=subprocess.STDOUT)
                    
                    today = DT.date.today(); later = today + DT.timedelta(days=masa_aktif)
                    exp_date_str = later.strftime("%Y-%m-%d")
                    gen_date = today.strftime("%d/%m/%Y")
                    quota_str = "Unlimited" if quota_gb == 0 else f"{quota_gb} GB"
                    
                    cmd_zivpn = f"""jq --arg u "{username}" '.auth.config += [$u]' /etc/zivpn/config.json > /tmp/c && mv /tmp/c /etc/zivpn/config.json && jq --arg u "{username}" --arg e "{exp_date_str}" --arg i "{limit_ip}" --arg q "0" '.[$u] = {{exp: $e, ip: $i, quota: "0"}}' /etc/zivpn/user-db.json > /tmp/d && mv /tmp/d /etc/zivpn/user-db.json && systemctl restart zivpn"""
                    subprocess.run(cmd_zivpn, shell=True)
                    
                    sisa_saldo = database.get_saldo(user_id)

                    msg_sukses = f"""
<code>⚡ PREMIUM SSH & ZIVPN ACCOUNT ⚡
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
 ☁️ INFORMASI AKUN SSH & ZIVPN
👤 Username : {username}
🔑 Password : {password}
🌐 Domain   : {DOMAIN}
📅 Expired  : {exp_date_str}
📱 Limit IP : {limit_ip} Device
💾 Quota    : {quota_str}
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
 🔌 SSH WS   : 80
 🛡️ SSH SSL  : 443
 🔮 UDP GW   : 1-65535
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
 🔗 FORMAT KONEKSI

• WS Format:
{DOMAIN}:80@{username}:{password}

• TLS Format:
{DOMAIN}:443@{username}:{password}

• UDP Format:
{DOMAIN}:1-65535@{username}:{password}

• ZIVPN Format:
UDP SERVER: {DOMAIN} UDP PASSWORD: {username}
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
ᵗᵉʳⁱᵐᵃᵏᵃˢⁱʰ ᵗᵉˡᵃʰ ᵐᵉⁿᵍᵍᵘⁿᵃᵏᵃⁿ ˡᵃʸᵃⁿᵃⁿ ᵏᵃᵐⁱ
Generated on {gen_date}
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
💵 Harga      : Rp {harga_produk:,}
💳 Sisa Saldo : Rp {sisa_saldo:,}
</code>"""
                    await msg_proc.edit(msg_sukses, parse_mode='html', buttons=[[Button.inline("‹ Menu ›", "menu_as_user")]])
                
                except subprocess.CalledProcessError as e:
                    database.tambah_saldo(user_id, harga_produk, "REFUND: Create Failed")
                    btns_retry = [[Button.inline("↻ Coba Nama Lain", data=event.data)], [Button.inline("‹ Menu ›", "menu_as_user")]]
                    if e.returncode == 9:
                        await msg_proc.edit(f"❌ <b>Gagal:</b> Username '{username}' sudah ada.\nSaldo telah dikembalikan.\n\nSilakan klik tombol di bawah untuk mencoba nama lain.", buttons=btns_retry, parse_mode='html')
                    else:
                        await msg_proc.edit(f"❌ Error System: {e.output.decode()}\nSaldo dikembalikan.", buttons=btns_retry, parse_mode='html')
                except Exception as e:
                    database.tambah_saldo(user_id, harga_produk, "REFUND: Error")
                    await msg_proc.edit(f"❌ Error: {e}", parse_mode='html')
            else:
                await msg_proc.edit("❌ Saldo Kurang/Gagal Transaksi", parse_mode='html')

    except Exception as e: await event.respond(f"Error: {e}")

# =================================================================
# 7. MONITOR LOGIN & TRIAL & MENU
# =================================================================
@bot.on(events.CallbackQuery(data=b'login-ssh'))
async def login_ssh_h(event):
    sender = await event.get_sender()
    if str(sender.id) != config.OWNER_ID and valid(str(sender.id)) != "true": return await event.answer("Akses Ditolak", alert=True)
    await event.answer("⌛ Memindai...", alert=False)
    msg = get_ssh_monitor_data()
    btns = [[Button.inline("🔄 REFRESH", "login-ssh")], [Button.inline("‹ Kembali ›", "ssh")]]
    try: await event.edit(msg, buttons=btns, parse_mode='html')
    except: await event.answer("✅ Updated.", alert=False)

@bot.on(events.CallbackQuery(data=b'trial-ssh'))
async def trial_ssh(event):
    chat = event.chat_id; sender = await event.get_sender()
    if str(sender.id) != config.OWNER_ID and valid(str(sender.id)) != "true": return
    async def trial_proc():
        try:
            async with bot.conversation(chat, timeout=60) as conv:
                await event.respond("<b>⏱️ Menit:</b>", parse_mode='html')
                exp = (await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text.strip()
            
            user = "trial"+str(random.randint(100,999)); pw="1"
            subprocess.run(f'useradd -e "`date -d "{exp} minutes" +"%Y-%m-%d %H:%M:%S"`" -s /bin/false -M {user} && echo "{user}:{pw}" | chpasswd', shell=True)
            
            tomorrow = DT.date.today() + DT.timedelta(days=1); exp_date_str = tomorrow.strftime("%Y-%m-%d")
            cmd_zivpn = f"""jq --arg u "{user}" '.auth.config += [$u]' /etc/zivpn/config.json > /tmp/c && mv /tmp/c /etc/zivpn/config.json && jq --arg u "{user}" --arg e "{exp_date_str}" --arg i "1" --arg q "1" '.[$u] = {{exp: $e, ip: "1", quota: "1"}}' /etc/zivpn/user-db.json > /tmp/d && mv /tmp/d /etc/zivpn/user-db.json && systemctl restart zivpn"""
            subprocess.run(cmd_zivpn, shell=True)

            msg = f"""
<code>⚡ TRIAL PREMIUM SSH & ZIVPN ⚡
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
👤 Username : {user}
🔑 Password : {pw}
🌐 Domain   : {DOMAIN}
⏱️ Expired  : {exp} Menit
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
🔗 FORMAT KONEKSI

• WS Format:
{DOMAIN}:80@{user}:{pw}

• TLS Format:
{DOMAIN}:443@{user}:{pw}

• UDP Format:
{DOMAIN}:1-65535@{user}:{pw}

• ZIVPN Format:
UDP SERVER: {DOMAIN} UDP PASSWORD: {user}
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬</code>
"""
            await event.respond(msg, buttons=[[Button.inline("‹ Menu ›", "menu")]], parse_mode='html')
        except: pass
    await trial_proc()

@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh_menu(event):
    sender = await event.get_sender(); user_id = str(sender.id)
    is_admin = (user_id == config.OWNER_ID) or (valid(user_id) == "true")
    if is_admin:
        msg = "<b>☁️ SSH MANAGER (ADMIN)</b>\nSilakan kelola server anda."
        buttons = [
            [Button.inline("☁️ TRIAL SSH ","trial-ssh"), Button.inline("⚡ CREATE SSH ","create-ssh")],
            [Button.inline("🗑️ DELETE SSH","delete-ssh"), Button.inline("🔐 CHECK LOGIN","login-ssh")],
            [Button.inline("📊 LIST USER ","show-ssh")], 
            [Button.inline("‹ Main Menu ›","menu")]
        ]
    else:
        msg = "<b>☁️ LAYANAN SSH PREMIUM</b>"
        buttons = [[Button.inline("🛒 BELI SSH", "list_harga")], [Button.inline("‹ Kembali ›","menu")]]
    await event.edit(msg, buttons=buttons, parse_mode='html')