from telethon import *
import datetime as DT
import requests, time, os, subprocess, re, sqlite3, sys, random, base64, json, math
import logging

# Konfigurasi Logging agar error terlihat di terminal
logging.basicConfig(level=logging.INFO)
uptime = DT.datetime.now()

# Load Variabel
try:
    exec(open("kyt/var.txt","r").read())
except Exception as e:
    print(f"Error loading var.txt: {e}")

# Start Bot
try:
    bot = TelegramClient("ddsdswl","6","eb06d4abfb49dc3eeb1aeb98ae0f581e").start(bot_token=BOT_TOKEN)
except Exception as e:
    print(f"Error starting TelegramClient: {e}")
    sys.exit()

# Setup Database Awal
try:
    # Cek koneksi awal
    x = sqlite3.connect("kyt/database.db")
    c = x.cursor()
    # Buat tabel jika belum ada
    c.execute("CREATE TABLE IF NOT EXISTS admin (user_id)")
    # Cek apakah admin sudah ada?
    c.execute("SELECT user_id FROM admin")
    if c.fetchone() is None:
        c.execute("INSERT INTO admin (user_id) VALUES (?)",(ADMIN,))
        x.commit()
    x.close()
except Exception as e:
    print(f"Error init database: {e}")

def get_db():
    x = sqlite3.connect("kyt/database.db")
    x.row_factory = sqlite3.Row
    return x

def valid(id):
    conn = None
    try:
        conn = get_db()
        cursor = conn.execute("SELECT user_id FROM admin")
        all_admins = cursor.fetchall()
        
        # Konversi semua ID admin di database menjadi STRING agar akurat
        admin_list = [str(row[0]) for row in all_admins]
        
        # Bandingkan ID input (String) dengan Database (String)
        if str(id) in admin_list:
            return "true"
        else:
            return "false"
            
    except Exception as e:
        print(f"Error in valid(): {e}")
        return "false" # Jika error, anggap member biasa (jangan macet)
        
    finally:
        # PENTING: Tutup koneksi agar tidak memory leak / database locked
        if conn:
            conn.close()

def convert_size(size_bytes):
   if size_bytes == 0:
       return "0B"
   size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
   i = int(math.floor(math.log(size_bytes, 1024)))
   p = math.pow(1024, i)
   s = round(size_bytes / p, 2)
   return "%s %s" % (s, size_name[i])