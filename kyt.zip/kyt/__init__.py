from telethon import *
import datetime as DT
import requests, time, os, subprocess, re, sqlite3, sys, random, base64, json, math
import logging

# =================================================================
# KONFIGURASI AWAL
# =================================================================
logging.basicConfig(level=logging.INFO)
uptime = DT.datetime.now()

# 1. LOAD VARIABEL DARI var.txt
# Pastikan file var.txt memiliki baris: ADMIN="123456" dan BOT_TOKEN="123:abc"
try:
    # Menggunakan absolute path agar aman saat dijalankan systemd
    # Jika error file not found, sesuaikan path ini:
    var_path = "kyt/var.txt" 
    
    if os.path.exists(var_path):
        exec(open(var_path, "r").read())
    else:
        # Fallback jika dijalankan dari folder /usr/bin/kyt/
        exec(open("/usr/bin/kyt/var.txt", "r").read())
        
except Exception as e:
    print(f"⚠️ Error loading var.txt: {e}")
    # Default nilai jika gagal load (Mencegah crash)
    if 'ADMIN' not in locals(): ADMIN = "0"
    if 'BOT_TOKEN' not in locals(): 
        print("❌ BOT_TOKEN tidak ditemukan di var.txt! Bot akan berhenti.")
        sys.exit()

# 2. START BOT TELEGRAM CLIENT
try:
    # Session name 'kyt_session' agar tidak perlu login ulang terus menerus
    bot = TelegramClient("kyt_session", 6, "eb06d4abfb49dc3eeb1aeb98ae0f581e").start(bot_token=BOT_TOKEN)
    print("✅ Telegram Client Berjalan...")
except Exception as e:
    print(f"❌ Error starting TelegramClient: {e}")
    sys.exit()

# 3. SETUP DATABASE (AUTO ADD ADMIN)
try:
    db_path = "kyt/database.db"
    
    # Cek koneksi
    x = sqlite3.connect(db_path)
    c = x.cursor()
    
    # Buat tabel jika belum ada
    c.execute("CREATE TABLE IF NOT EXISTS admin (user_id)")
    
    # --- LOGIKA PERBAIKAN: AUTO INJECT ADMIN ---
    # Cek apakah ADMIN dari var.txt sudah ada di database?
    str_admin = str(ADMIN).strip().replace('"', '') # Bersihkan ID
    
    c.execute("SELECT user_id FROM admin WHERE user_id = ?", (str_admin,))
    if c.fetchone() is None:
        # Jika belum ada, masukkan!
        c.execute("INSERT INTO admin (user_id) VALUES (?)", (str_admin,))
        x.commit()
        print(f"➕ Admin Baru Ditambahkan ke Database: {str_admin}")
    else:
        print(f"✅ Admin {str_admin} sudah terdaftar di Database.")
        
    x.close()
except Exception as e:
    print(f"❌ Error init database: {e}")

# =================================================================
# FUNGSI GLOBAL PEMBANTU
# =================================================================

def get_db():
    """Membuka koneksi database"""
    # Sesuaikan path jika perlu "/usr/bin/kyt/database.db"
    x = sqlite3.connect("kyt/database.db")
    x.row_factory = sqlite3.Row
    return x

def valid(id):
    """Mengecek apakah user ID terdaftar sebagai Admin"""
    conn = None
    try:
        conn = get_db()
        cursor = conn.execute("SELECT user_id FROM admin")
        all_admins = cursor.fetchall()
        
        # Konversi semua data di DB ke String untuk pencocokan akurat
        # Hapus spasi atau karakter aneh jika ada
        admin_list = [str(row[0]).strip() for row in all_admins]
        
        # ID yang dicek juga harus string
        check_id = str(id).strip()
        
        if check_id in admin_list:
            return "true"
        else:
            return "false"
            
    except Exception as e:
        print(f"Error in valid(): {e}")
        return "false"
        
    finally:
        # PENTING: Tutup koneksi untuk mencegah 'database locked'
        if conn:
            conn.close()

def convert_size(size_bytes):
    """Konversi bytes ke KB, MB, GB"""
    if size_bytes == 0:
        return "0B"
    size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
    i = int(math.floor(math.log(size_bytes, 1024)))
    p = math.pow(1024, i)
    s = round(size_bytes / p, 2)
    return "%s %s" % (s, size_name[i])